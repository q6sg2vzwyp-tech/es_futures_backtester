#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
paper_trader.py

ES Paper Trader (modular rebuild, crash-resilient, safer learning) - N+ build

Bootstrap:
- builds shared objects
- restores state
- builds ctx
- calls loop_core.run_loop_iteration(ctx) forever

NEW (2025-12-23):
- Shadow window is now configurable via CLI:
    --shadow-start-ct HH:MM
    --shadow-end-ct   HH:MM
  and is logged at startup so "outside_shadow_window" is never a mystery.

PATCH ROLLUP (this file):
- Adds missing CLI flag: --auto-flat-ct (was referenced but not defined).
- Makes CT time parsing tolerant of "8:35" as well as "08:35".
- Ensures required directories exist (run/, results/, data/state/, logs/, learn/).
- Seeds learn/real_arms.json at startup if absent (stable promotion allowlist).
- Keeps preclose sweep + weekend flatten wiring in ctx.
- Keeps runtime_state.json save-throttle key in ctx (loop_core uses it).

LOGGING HARDENING (2026-01-01):
- Trades CSV (results/trades.csv) is auto-repaired at startup if it has:
    * blank header columns (e.g., trailing commas)
    * rows with extra empty columns
  Repair rewrites to the canonical 8-column schema:
    timestamp,side,qty,entry_px,exit_px,pnl,R,tags
  This prevents repeated downstream parsing issues (intraday rebuild, hb monitor, sharpe, bayes training).
- Shadow logging already uses canonical writer (shadow_logs.py) via make_shadow_roundtrip_cb().
"""

from __future__ import annotations

import sys
import os
import csv
import time
import json
import argparse
import datetime as dt
import tempfile
from typing import Optional, Dict, Any, List

from ib_insync import Ticker, MarketOrder

import utils
import order_core
from loop_core import run_loop_iteration

from risk_core import DayRisk, WeekState, default_week_state, roll_week_if_needed
from learner_bandit import ThompsonGaussian, save_thompson, load_thompson
from learner_meta import MetaLearner

from strategy_core import BarBuffer, DEFAULT_ARMS, REAL_ARMS, build_signal_and_bands

from hb_core import build_and_write_heartbeat
from ib_core import connect_ib, resolve_contract

from position_core import compute_position
from bayes_core import (
    build_bayes_training_set,
    maybe_apply_bayes_best,
    run_eod_bayes_opt_filtered,
)
from startup_core import maybe_daily_restart, has_hedge_protection, attach_startup_protection
from margin_core import MarginManager

from shadow_core import ShadowSim

from pt_utils import (
    build_bandit_hb_fields,
    recompute_intraday_from_trades,
)

from state_core import (
    log_state_core_provenance,
    restore_runtime_into_objects,
)

from day_policy_core import DayPolicyState

# Canonical shadow log writer (ONE truth for CSV schema)
from shadow_logs import append_shadow_roundtrip_log as append_shadow_roundtrip_log_canon


# --------------------
# Paths & constants
# --------------------
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
LOG_DIR = os.path.join(BASE_DIR, "logs")
RUN_DIR = os.path.join(BASE_DIR, "run")
RESULTS_DIR = os.path.join(BASE_DIR, "results")
DATA_STATE_DIR = os.path.join(BASE_DIR, "data", "state")

HB_PATH = os.path.join(BASE_DIR, "run", "heartbeat.txt")


def _atomic_write_text(path: str, data: str) -> None:
    """Atomic-ish write (Windows-safe) using a temp file + replace."""
    import tempfile
    d = os.path.dirname(path)
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix="._tmp_", suffix=".txt", dir=d)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(data)
        os.replace(tmp, path)
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


def _hb_emit_factory(hb_path: str, logger):
    """
    Provides ctx['_hb_emit'] expected by loop_core.

    loop_core will call _hb_emit(**fields) frequently. We write a small JSON
    heartbeat to hb_path that hb_monitor can read.
    """

    def _hb_emit(**fields):
        try:
            payload = dict(fields)

            # normalize common field names
            if "hb_state" in payload and "state" not in payload:
                payload["state"] = payload.pop("hb_state")
            if "hb_pos_state" in payload and "pos_state" not in payload:
                payload["pos_state"] = payload.pop("hb_pos_state")

            # always have a timestamp
            payload.setdefault("ts", dt.datetime.now(dt.timezone.utc).astimezone().isoformat())

            _atomic_write_text(hb_path, json.dumps(payload, ensure_ascii=False))
        except Exception as e:
            # Never crash the trader for heartbeat issues, but do surface it.
            try:
                logger.error("[hb_emit] failed to write heartbeat to %s: %s", hb_path, e)
            except Exception:
                pass

    return _hb_emit
LEARN_DIR = os.path.join(BASE_DIR, "learn")
LEARN_MODEL_PATH = os.path.join(LEARN_DIR, "bandit_state.json")
LEARN_BAYES_BEST = os.path.join(LEARN_DIR, "bayes_best_params.json")
REAL_ARMS_JSON = os.path.join(LEARN_DIR, "real_arms.json")

TRADE_LOG_CSV = os.path.join(BASE_DIR, "results", "trades.csv")
DAILY_RESTART_JSON = os.path.join(BASE_DIR, "data", "state", "daily_restart.json")
RUNTIME_STATE_JSON = os.path.join(BASE_DIR, "data", "state", "runtime_state.json")
SHADOW_ROUNDTRIP_LOG = os.path.join(BASE_DIR, "results", "shadow_roundtrips.csv")
SHADOW_MODEL_JSON = os.path.join(LEARN_DIR, "shadow_model.json")
BAYES_TRAIN_CSV = os.path.join(BASE_DIR, "results", "trades_bayes_clean.csv")

BAYES_SOURCE = "cli"
DAILY_RESTART_CT = dt.time(16, 30)

ORPHAN_SWEEP_COOLDOWN = 30.0
IB_ERROR_DECAY_SEC = 120.0

US_MARKET_HOLIDAYS = {
    dt.date(2025, 1, 1),
    dt.date(2025, 1, 20),
    dt.date(2025, 2, 17),
    dt.date(2025, 4, 18),
    dt.date(2025, 5, 26),
    dt.date(2025, 7, 4),
    dt.date(2025, 9, 1),
    dt.date(2025, 11, 27),
    dt.date(2025, 12, 25),
}

# Defaults; now overridable via CLI
SHADOW_START_DEFAULT = "08:30"
SHADOW_END_DEFAULT = "15:15"

AUTO_FLAT_CT: Optional[dt.time] = None


# --------------------
# Helpers
# --------------------
def is_us_market_holiday(d: dt.date) -> bool:
    return d in US_MARKET_HOLIDAYS


def _atomic_replace(path: str, content: str) -> None:
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd = None
    tmp_path = None
    try:
        fd, tmp_path = tempfile.mkstemp(prefix="atomic_", suffix=".tmp", dir=d, text=True)
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(content)
            if not content.endswith("\n"):
                f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
        tmp_path = None
    finally:
        try:
            if tmp_path and os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass


def _repair_trades_csv_if_needed(path: str, logger) -> bool:
    """
    Repairs results/trades.csv if header has blank columns or rows have trailing empties.
    Canonical schema (8 columns):
      timestamp,side,qty,entry_px,exit_px,pnl,R,tags

    Returns True if a repair was performed.
    """
    CANON = ["timestamp", "side", "qty", "entry_px", "exit_px", "pnl", "R", "tags"]

    if not os.path.exists(path):
        return False

    try:
        with open(path, "r", encoding="utf-8", newline="") as f:
            first = f.readline()
            if not first:
                return False
            raw_header = [h.strip() for h in first.rstrip("\r\n").split(",")]

            header_has_blanks = any(h == "" for h in raw_header)
            header_len = len(raw_header)

            # Quick accept: exact canonical header
            if raw_header[: len(CANON)] == CANON and (not header_has_blanks) and header_len == len(CANON):
                return False

        rows_out: List[List[str]] = []

        with open(path, "r", encoding="utf-8", newline="") as f:
            r = csv.reader(f)
            hdr = next(r, None)
            if hdr is None:
                return False

            for row in r:
                if not row:
                    continue
                # trim trailing empties
                while row and (row[-1] == "" or row[-1] is None):
                    row = row[:-1]
                # keep first 8, pad if needed
                row8 = (row[:8] + [""] * 8)[:8]
                rows_out.append([str(x) if x is not None else "" for x in row8])

        # Emit via csv.writer for correct quoting
        from io import StringIO

        buf = StringIO()
        w = csv.writer(buf, lineterminator="\n")
        w.writerow(CANON)
        for row8 in rows_out:
            w.writerow(row8)

        _atomic_replace(path, buf.getvalue())
        logger.warning(
            "[trades_csv] repaired schema -> canonical 8-column header (timestamp,side,qty,entry_px,exit_px,pnl,R,tags): %s",
            path,
        )
        return True

    except Exception as e:
        logger.error("[trades_csv] repair failed for %s: %s", path, e)
        return False


def compute_boost_factor(
    boost_mode: str,
    meta: MetaLearner,
    day_risk: DayRisk,
    week_state: WeekState,
    equity: float,
    equity_hwm: float,
    logger,
) -> float:
    mode = (boost_mode or "off").lower().strip()
    if mode == "off":
        return 1.0

    meta_ema = float(getattr(meta, "ema_R", 0.0) or 0.0)
    week_R = float(getattr(week_state, "week_R", 0.0) or 0.0)
    consec = int(getattr(day_risk, "consec_losses", 0) or 0)

    dd = 0.0
    if equity_hwm and equity_hwm > 0:
        dd = max(0.0, (equity_hwm - equity) / equity_hwm)

    boost = 1.0
    if meta_ema > 0.25:
        boost += 0.10
    if meta_ema > 0.75:
        boost += 0.10

    if dd >= 0.02:
        boost -= 0.10
    if dd >= 0.05:
        boost -= 0.15

    if consec >= 2:
        boost -= 0.10
    if consec >= 4:
        boost -= 0.10

    if week_R > 1.0:
        boost += 0.05
    if week_R < -1.0:
        boost -= 0.05

    if mode == "normal":
        boost = max(0.50, min(1.50, boost))
    elif mode == "war":
        boost = max(0.40, min(2.00, boost))
    else:
        boost = max(0.50, min(1.50, boost))

    return float(boost)




def assert_ctx_wiring(ctx: Dict[str, Any]) -> None:
    """Fail-fast wiring validation. Refuses to run if critical hooks are missing or no-op placeholders."""
    import inspect

    required_keys = [
        # core
        "args","logger","ib","con","ticker","bars",
        "day_risk","week_state","bandit","meta","shadow","margin_mgr",
        "day_policy_state","eod_state",
        # config/schedules
        "trade_start","trade_end","SHADOW_START_CT","SHADOW_END_CT",
        "AUTO_FLAT_CT","PRE_CLOSE_SWEEP_CT","WEEKEND_FLATTEN","DAILY_RESTART_CT",
        # paths
        "HB_PATH","TRADE_LOG_CSV","RUNTIME_STATE_JSON","DAILY_RESTART_JSON","LEARN_MODEL_PATH",
        # hooks
        "is_us_market_holiday","maybe_daily_restart","build_and_write_heartbeat",
        "_hb_emit",
        "append_shadow_roundtrip_log","build_bandit_hb_fields","compute_boost_factor",
        "roll_week_if_needed",
        # day-policy flatten hooks (must not be placeholders)
        "flatten_all","place_market_flat",
    ]
    missing = [k for k in required_keys if k not in ctx]
    if missing:
        raise RuntimeError(f"[wiring] ctx missing required keys: {missing}")

    def _is_noop(fn) -> bool:
        if not callable(fn):
            return True
        try:
            src = inspect.getsource(fn)
        except Exception:
            return False  # cannot prove noop
        s = src.strip()
        if s.startswith("lambda") and "None" in s:
            return True
        if "pass" in s and len(s.splitlines()) <= 6:
            return True
        return False

    must_be_callable = [
        "is_us_market_holiday","maybe_daily_restart","build_and_write_heartbeat",
        "append_shadow_roundtrip_log","build_bandit_hb_fields","compute_boost_factor",
        "roll_week_if_needed","flatten_all","place_market_flat",
    ]
    for k in must_be_callable:
        fn = ctx.get(k)
        if not callable(fn):
            raise RuntimeError(f"[wiring] {k} is not callable")
        if _is_noop(fn):
            raise RuntimeError(f"[wiring] {k} appears to be a placeholder/no-op; refusing to run")

    ctx["logger"].info("[wiring] ctx wiring self-test PASSED")
def make_shadow_roundtrip_cb(path: str, *, utils_module):
    """
    Stable callback that writes to canonical shadow_roundtrips.csv schema via shadow_logs.py.

    Supports BOTH calling conventions:
      A) ShadowSim-style row emission:
         - cb(row_dict)
         - cb(row=row_dict)
         - cb(**row_dict)   [heuristic: looks like a canonical row]
      B) loop_core legacy kwargs signature:
         - cb(now_ct=..., day=..., regime=..., arm=..., side=..., qty=..., entry_px=..., exit_px=..., pnl=..., R=..., reason=...)

    Also writes an optional debug breadcrumb at logs/shadow_roundtrip_cb.log to prove the callback is firing.
    """

    def _write_row(row: Dict[str, Any]) -> None:
        try:
            dbg = os.path.join(LOG_DIR, "shadow_roundtrip_cb.log")
            utils_module.ensure_dir(os.path.dirname(dbg))
            with open(dbg, "a", encoding="utf-8") as f:
                f.write(
                    f"{dt.datetime.now().isoformat()} "
                    f"arm={row.get('arm')} side={row.get('side')} "
                    f"R={row.get('R')} close_gate={row.get('close_gate')} "
                    f"keys={sorted(list(row.keys()))}\n"
                )
        except Exception:
            pass

        append_shadow_roundtrip_log_canon(row, path=path, utils_module=utils_module)

    def _cb(*args, **kwargs) -> None:
        # Form A: cb(row_dict)
        if args and isinstance(args[0], dict):
            _write_row(args[0])
            return

        # Form A2: cb(row=row_dict)
        if "row" in kwargs and isinstance(kwargs["row"], dict):
            _write_row(kwargs["row"])
            return

        # Form A3: cb(**row_dict) with canonical keys
        if "entry_ts" in kwargs and "exit_ts" in kwargs and "arm" in kwargs:
            _write_row(dict(kwargs))
            return

        # Form B: legacy kwargs signature -> map into canonical
        now_ct = kwargs.get("now_ct")
        if hasattr(now_ct, "isoformat"):
            ts = now_ct.isoformat(timespec="seconds")
        else:
            ts = dt.datetime.now().isoformat(timespec="seconds")

        row = {
            "entry_ts": ts,
            "exit_ts": ts,
            "arm": str(kwargs.get("arm", "unknown")),
            "side": str(kwargs.get("side", "")).upper(),
            "entry_px": float(kwargs.get("entry_px", 0.0) or 0.0),
            "exit_px": float(kwargs.get("exit_px", 0.0) or 0.0),
            "pnl_usd": float(kwargs.get("pnl", 0.0) or 0.0),
            "R": float(kwargs.get("R", 0.0) or 0.0),
            "open_gate": str(kwargs.get("open_gate", "") or ""),
            "close_gate": str(kwargs.get("reason", "") or kwargs.get("close_gate", "") or ""),
            "day": str(kwargs.get("day", "") or ""),
            "week_R": kwargs.get("week_R", ""),
            "meta_ema_R": kwargs.get("meta_ema_R", ""),
            "regime": str(kwargs.get("regime", "unknown") or "unknown"),
        }
        _write_row(row)

    return _cb


def _load_real_arms(path: str, logger) -> List[str]:
    """
    Load persisted real arms list from JSON; fallback to strategy_core.REAL_ARMS.
    Accepts either:
      - {"real_arms": [...]} dict
      - [...] raw list
    """
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                obj = json.load(f)
            arms = obj.get("real_arms") if isinstance(obj, dict) else obj
            if isinstance(arms, list):
                out = [str(a).strip() for a in arms if str(a).strip()]
                if out:
                    logger.info("[real_arms] loaded %d arms from %s", len(out), path)
                    return out
    except Exception as e:
        logger.warning("[real_arms] failed to load %s: %s", path, e)

    logger.info("[real_arms] using default REAL_ARMS (%d arms)", len(REAL_ARMS))
    return REAL_ARMS.copy()


def _persist_real_arms(path: str, arms: List[str], logger) -> None:
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        payload = {
            "updated": utils.ct_now().isoformat(timespec="seconds"),
            "real_arms": [str(a).strip() for a in arms if str(a).strip()],
            "note": "seeded at startup by paper_trader.py (may be updated by loop_core promotion)",
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        logger.info("[real_arms] seeded %s", path)
    except Exception as e:
        logger.warning("[real_arms] failed to persist %s: %s", path, e)


def _parse_hhmm(name: str, s: str, logger) -> dt.time:
    try:
        return dt.datetime.strptime(str(s).strip(), "%H:%M").time()
    except Exception:
        logger.warning("[config] invalid %s=%r (expected HH:MM); using 00:00", name, s)
        return dt.time(0, 0)


def _parse_ct_time(_flag_name: str, value: Optional[str]) -> Optional[dt.time]:
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    if len(s) >= 4 and s[1] == ":":
        s = "0" + s
    try:
        return dt.datetime.strptime(s, "%H:%M").time()
    except Exception:
        return None


# --------------------
# CLI
# --------------------
def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="ES Paper Trader (modular rebuild)")

    p.add_argument("--ib-host", default="127.0.0.1")
    p.add_argument("--ib-port", type=int, default=4002)
    p.add_argument("--ib-client-id", type=int, default=111)

    p.add_argument("--local-symbol", default="auto")
    p.add_argument("--exchange", default="GLOBEX")
    p.add_argument("--currency", default="USD")

    p.add_argument("--place-orders", action="store_true")
    p.add_argument("--use-ib-pnl", action="store_true")
    p.add_argument("--risk-profile", default="balanced")
    p.add_argument("--learn-mode", default="advisory", choices=["off", "advisory", "control"])

    p.add_argument("--trade-start-ct", default="8:35")
    p.add_argument("--trade-end-ct", default="15:00")
    p.add_argument("--session-reset-cts", default="08:30")
    p.add_argument("--vwap-reset-on-session", action="store_true")

    p.add_argument(
        "--auto-flat-ct",
        type=str,
        default="",
        help="HH:MM CT; auto-flatten time (optional). Example: 13:35. Leave blank to disable.",
    )

    p.add_argument(
        "--preclose-sweep-ct",
        type=str,
        default="15:55",
        help="HH:MM CT; safety sweep time: retry flatten-until-flat and then lock out new entries for the day",
    )

    p.add_argument(
        "--weekend-flatten",
        action="store_true",
        help="If set, Sat/Sun will force flatten-until-flat and halt trading (prevents weekend carry).",
    )

    # Shadow window controls
    p.add_argument("--shadow-start-ct", default=SHADOW_START_DEFAULT, help="HH:MM CT (shadow learning window start)")
    p.add_argument("--shadow-end-ct", default=SHADOW_END_DEFAULT, help="HH:MM CT (shadow learning window end)")

    # Shadow master enable switch (defaults ON). Supports both:
    #   --shadow-enabled / --no-shadow-enabled
    try:
        p.add_argument(
            "--shadow-enabled",
            dest="shadow_enabled",
            action=argparse.BooleanOptionalAction,
            default=True,
            help="Enable/disable the shadow simulator (shadow learning engine).",
        )
    except Exception:
        # Fallback (very old argparse): emulate ON-by-default with explicit disable flag.
        p.add_argument("--shadow-enabled", dest="shadow_enabled", action="store_true", default=True)
        p.add_argument("--no-shadow-enabled", dest="shadow_enabled", action="store_false")

    # ShadowSim knobs
    p.add_argument("--shadow-decision-bucket-sec", type=int, default=30, help="Shadow evaluation throttling bucket (seconds)")
    p.add_argument("--shadow-min-hold-sec", type=int, default=10, help="Minimum time to hold a shadow position before allowing exit")
    p.add_argument("--shadow-max-hold-sec", type=int, default=1800, help="Maximum time to hold a shadow position before forcing exit (seconds)")

    # Shadow overtrading rails
    p.add_argument("--shadow-max-roundtrips-per-day", type=int, default=60, help="Shadow: maximum completed roundtrips per day")
    p.add_argument("--shadow-max-roundtrips-per-hour", type=int, default=8, help="Shadow: maximum completed roundtrips per hour")
    p.add_argument("--shadow-post-close-cooldown-sec", type=int, default=30, help="Shadow: cooldown after ANY close before next open")
    p.add_argument("--shadow-post-loss-cooldown-sec", type=int, default=120, help="Shadow: extra cooldown after a losing close")

    p.add_argument("--min-seconds-between-entries", type=int, default=15)
    p.add_argument("--strategy-cooldown-sec", type=int, default=15)
    p.add_argument("--parent-to-mkt-sec", type=int, default=5)

    p.add_argument("--poll-hist-when-no-rt", action="store_true")
    p.add_argument("--poll-interval-sec", type=int, default=10)
    p.add_argument("--rt-staleness-sec", type=int, default=45)
    p.add_argument("--startup-delay-sec", type=int, default=0)

    p.add_argument(
        "--state-save-every-sec",
        dest="state_save_every_sec",
        type=float,
        default=5.0,
        help="Throttle runtime_state.json writes (seconds).",
    )

    p.add_argument("--start-contracts", type=int, default=2)
    p.add_argument("--max-contracts", type=int, default=6)
    p.add_argument("--risk-pct", type=float, default=0.015)
    p.add_argument("--risk-ticks", type=int, default=12)
    p.add_argument("--tp-R", type=float, default=1.0)
    p.add_argument("--tick-size", type=float, default=0.25)

    p.add_argument("--pos-age-cap-sec", type=int, default=900)
    p.add_argument("--pos-age-minR", type=float, default=0.5)

    p.add_argument("--hwm-stepdown", action="store_true")
    p.add_argument("--hwm-stepdown-dollars", type=float, default=5000.0)

    p.add_argument("--day-guard-pct", type=float, default=0.0)
    p.add_argument("--max-trades-per-day", type=int, default=20)

    p.add_argument("--max-trades-per-hour", type=int, default=3)
    p.add_argument("--post-loss-cooldown-sec", type=int, default=600)

    p.add_argument("--max-consec-losses", type=int, default=6)
    p.add_argument("--day-loss-cap-R", type=float, default=-5.0)
    p.add_argument("--weekly-cap-mult", type=float, default=4.0)

    p.add_argument("--post-flat-cooldown-sec", type=int, default=60)

    p.add_argument("--learn-while-capped", action="store_true")
    p.add_argument("--learn-log", action="store_true")
    p.add_argument("--learn-log-dir", default=os.path.join(BASE_DIR, "logs", "learn"))

    p.add_argument("--use-bayes-best", action="store_true")
    p.add_argument("--eod-min-trades", type=int, default=3)

    p.add_argument(
        "--boost-mode",
        default="off",
        choices=["off", "normal", "war"],
        help="Dynamic risk scaling: off | normal | war",
    )

    # shadow → real promotion
    p.add_argument("--promote-shadow-to-real", action="store_true")
    p.add_argument("--promote-min-shadow-trades", type=int, default=30)
    p.add_argument("--promote-min-real-trades", type=int, default=10)
    p.add_argument("--promote-meanR-threshold", type=float, default=0.10)

    return p


# --------------------
# Main
# --------------------
def main() -> None:
    global BAYES_SOURCE, AUTO_FLAT_CT

    args = build_arg_parser().parse_args()

    # Ensure folders exist (prevents first-run crashes)
    utils.ensure_dir(LOG_DIR)
    utils.ensure_dir(LEARN_DIR)
    utils.ensure_dir(RUN_DIR)
    utils.ensure_dir(RESULTS_DIR)
    utils.ensure_dir(DATA_STATE_DIR)

    logger = utils.setup_logger(LOG_DIR, "es_paper")
    log_state_core_provenance(logger)

    # --- Schema helpers ---
    def _ensure_csv_header(path: str, header: str) -> None:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

        if not os.path.exists(path):
            with open(path, "w", encoding="utf-8", newline="") as f:
                f.write(header + "\n")
            return

        with open(path, "r", encoding="utf-8-sig", newline="") as f:
            first = (f.readline() or "").strip()

        if first != header:
            raise RuntimeError(
                f"CSV header mismatch for {path}\nExpected: {header}\nFound:    {first}"
            )

    # --- trades.csv: REPAIR first, then enforce ---
    _repair_trades_csv_if_needed(TRADE_LOG_CSV, logger)
    _ensure_csv_header(TRADE_LOG_CSV, "timestamp,side,qty,entry_px,exit_px,pnl,R,tags")

    # --- shadow_roundtrips.csv: strict (canonical writer should keep it stable) ---
    _ensure_csv_header(
        SHADOW_ROUNDTRIP_LOG,
        "entry_ts,exit_ts,arm,side,entry_px,exit_px,pnl_usd,R,open_gate,close_gate,day,week_R,meta_ema_R,regime",
    )

    logger.info("[schema_guard] trades.csv=OK (8 cols), shadow_roundtrips.csv=OK (14 cols)")
    logger.info("[shadow_log] roundtrip csv: %s", SHADOW_ROUNDTRIP_LOG)

    # --- Auto-flat ---
    AUTO_FLAT_CT = _parse_ct_time("auto_flat_ct", getattr(args, "auto_flat_ct", None))
    if AUTO_FLAT_CT is not None:
        logger.info("[auto_flat] configured auto-flat time at %s CT", AUTO_FLAT_CT)
    elif getattr(args, "auto_flat_ct", None):
        logger.warning(
            "[auto_flat] Invalid --auto-flat-ct value %r, expected HH:MM; auto-flat disabled",
            args.auto_flat_ct,
        )

    # --- Preclose sweep ---
    PRE_CLOSE_SWEEP_CT = _parse_ct_time("preclose_sweep_ct", getattr(args, "preclose_sweep_ct", None))
    if PRE_CLOSE_SWEEP_CT is not None:
        logger.info("[preclose_sweep] configured preclose sweep time at %s CT", PRE_CLOSE_SWEEP_CT)
    elif getattr(args, "preclose_sweep_ct", None):
        logger.warning(
            "[preclose_sweep] Invalid --preclose-sweep-ct value %r, expected HH:MM; disabled",
            args.preclose_sweep_ct,
        )

    # Parse and LOG shadow window explicitly
    SHADOW_START_CT = _parse_hhmm("shadow_start_ct", args.shadow_start_ct, logger)
    SHADOW_END_CT = _parse_hhmm("shadow_end_ct", args.shadow_end_ct, logger)
    logger.info(
        "[shadow_window] %s -> %s CT",
        SHADOW_START_CT.isoformat(timespec="minutes"),
        SHADOW_END_CT.isoformat(timespec="minutes"),
    )

    margin_mgr = MarginManager(logger=logger, max_usage_soft=0.80, max_usage_hard=0.95)

    if args.learn_log:
        utils.ensure_dir(args.learn_log_dir)

    BAYES_SOURCE = maybe_apply_bayes_best(args, logger, LEARN_BAYES_BEST)

    # Safety clamps
    if args.min_seconds_between_entries < 10:
        logger.warning("[config] min_seconds_between_entries=%s is very low; clamping to 10.", args.min_seconds_between_entries)
        args.min_seconds_between_entries = 10

    if args.strategy_cooldown_sec < 10:
        logger.warning("[config] strategy_cooldown_sec=%s is very low; clamping to 10.", args.strategy_cooldown_sec)
        args.strategy_cooldown_sec = 10

    if getattr(args, "max_trades_per_hour", 3) < 1:
        logger.warning("[config] max_trades_per_hour=%s is invalid; clamping to 1.", args.max_trades_per_hour)
        args.max_trades_per_hour = 1

    if getattr(args, "post_loss_cooldown_sec", 600) < 0:
        logger.warning("[config] post_loss_cooldown_sec=%s is invalid; clamping to 0.", args.post_loss_cooldown_sec)
        args.post_loss_cooldown_sec = 0

    # Shadow rail clamps (avoid nonsense)
    if getattr(args, "shadow_max_roundtrips_per_hour", 8) < 1:
        logger.warning("[config] shadow_max_roundtrips_per_hour=%s invalid; clamping to 1.", args.shadow_max_roundtrips_per_hour)
        args.shadow_max_roundtrips_per_hour = 1
    if getattr(args, "shadow_max_roundtrips_per_day", 60) < 1:
        logger.warning("[config] shadow_max_roundtrips_per_day=%s invalid; clamping to 1.", args.shadow_max_roundtrips_per_day)
        args.shadow_max_roundtrips_per_day = 1
    if getattr(args, "shadow_post_close_cooldown_sec", 30) < 0:
        logger.warning("[config] shadow_post_close_cooldown_sec=%s invalid; clamping to 0.", args.shadow_post_close_cooldown_sec)
        args.shadow_post_close_cooldown_sec = 0
    if getattr(args, "shadow_post_loss_cooldown_sec", 120) < 0:
        logger.warning("[config] shadow_post_loss_cooldown_sec=%s invalid; clamping to 0.", args.shadow_post_loss_cooldown_sec)
        args.shadow_post_loss_cooldown_sec = 0

    if args.startup_delay_sec > 0:
        logger.info("Startup delay %ss...", args.startup_delay_sec)
        time.sleep(args.startup_delay_sec)

    ib = connect_ib(args, logger)

    # Load persisted real arms allowlist (promotion writes here)
    real_arms = _load_real_arms(REAL_ARMS_JSON, logger)
    if not os.path.exists(REAL_ARMS_JSON):
        _persist_real_arms(REAL_ARMS_JSON, real_arms, logger)

    # Bound shadow roundtrip callback (polymorphic + canonical)
    shadow_roundtrip_cb = make_shadow_roundtrip_cb(SHADOW_ROUNDTRIP_LOG, utils_module=utils)

    ctx: Dict[str, Any] = {
        "args": args,
        "logger": logger,
        "ib": ib,
        "con": None,
        "ticker": None,
        "last_fill_ts": None,
        "last_ib_err": None,
        "BAYES_SOURCE": BAYES_SOURCE,
        "AUTO_FLAT_CT": AUTO_FLAT_CT,
        "PRE_CLOSE_SWEEP_CT": PRE_CLOSE_SWEEP_CT,
        "WEEKEND_FLATTEN": bool(getattr(args, "weekend_flatten", False)),
        "HB_PATH": HB_PATH,
        "TRADE_LOG_CSV": TRADE_LOG_CSV,
        "RUNTIME_STATE_JSON": RUNTIME_STATE_JSON,
        "SHADOW_START_CT": SHADOW_START_CT,
        "SHADOW_END_CT": SHADOW_END_CT,
        "DAILY_RESTART_CT": DAILY_RESTART_CT,
        "DAILY_RESTART_JSON": DAILY_RESTART_JSON,
        "ORPHAN_SWEEP_COOLDOWN": ORPHAN_SWEEP_COOLDOWN,
        "IB_ERROR_DECAY_SEC": IB_ERROR_DECAY_SEC,
        "BAYES_TRAIN_CSV": BAYES_TRAIN_CSV,
        "LEARN_BAYES_BEST": LEARN_BAYES_BEST,
        "LEARN_MODEL_PATH": LEARN_MODEL_PATH,
        "REAL_ARMS_JSON": REAL_ARMS_JSON,
        "SHADOW_ROUNDTRIP_LOG": SHADOW_ROUNDTRIP_LOG,
        "real_arms": real_arms,
        "is_us_market_holiday": is_us_market_holiday,
        "maybe_daily_restart": maybe_daily_restart,
        "build_and_write_heartbeat": build_and_write_heartbeat,
        "_hb_emit": _hb_emit_factory(HB_PATH, logger),
        "build_bayes_training_set": build_bayes_training_set,
        "run_eod_bayes_opt_filtered": run_eod_bayes_opt_filtered,
        "roll_week_if_needed": roll_week_if_needed,
        "append_shadow_roundtrip_log": shadow_roundtrip_cb,
        "compute_boost_factor": compute_boost_factor,
        "build_bandit_hb_fields": build_bandit_hb_fields,
        "state_save_every_sec": float(getattr(args, "state_save_every_sec", 5.0) or 5.0),

        # Shadow rails config
        "shadow_max_roundtrips_per_day": int(getattr(args, "shadow_max_roundtrips_per_day", 60)),
        "shadow_max_roundtrips_per_hour": int(getattr(args, "shadow_max_roundtrips_per_hour", 8)),
        "shadow_post_close_cooldown_sec": int(getattr(args, "shadow_post_close_cooldown_sec", 30)),
        "shadow_post_loss_cooldown_sec": int(getattr(args, "shadow_post_loss_cooldown_sec", 120)),
    }

    def on_ib_error(reqId, errorCode, errorString, contract):
        code = int(errorCode)
        msg = str(errorString)
        ctx["last_ib_err"] = {
            "ts": dt.datetime.now().isoformat(timespec="seconds"),
            "code": code,
            "msg": msg,
            "reqId": int(reqId),
        }

        if code in (2103, 2104, 2105, 2106, 2119, 2157, 2158):
            logger.info("[IB_STATUS] reqId=%s code=%s msg=%s", reqId, code, msg)
            return
        if code in (1100, 1102):
            logger.error("[IB_CONN] reqId=%s code=%s msg=%s", reqId, code, msg)
            return
        if code == 2109:
            logger.info("[IB_ORDER_WARN] reqId=%s code=%s msg=%s", reqId, code, msg)
            return
        if code == 10148:
            if "state: Cancelled" in msg or "Completed" in msg:
                logger.debug("[IB_WARN_SUPPRESSED] reqId=%s code=%s msg=%s", reqId, code, msg)
            else:
                logger.warning("[IB_WARN] reqId=%s code=%s msg=%s", reqId, code, msg)
            return
        if code == 10147:
            logger.warning("[IB_WARN] reqId=%s code=%s msg=%s", reqId, code, msg)
            return
        if code == 202:
            logger.info("[IB_CANCEL] reqId=%s code=%s msg=%s", reqId, code, msg)
            return

        logger.error("[IB_ERROR] reqId=%s code=%s msg=%s", reqId, code, msg)

    def on_fill(trade, fill):
        try:
            exec_obj = getattr(fill, "execution", None)
            if exec_obj is None:
                return
            px = float(getattr(exec_obj, "price", 0.0))
            if px > 0:
                ctx["last_fill_ts"] = time.time()
                logger.info("[fill] price=%s qty=%s", px, float(getattr(exec_obj, "shares", 0.0)))
        except Exception as e:
            logger.error("[fill_handler] failed: %s", e)

    ib.errorEvent += on_ib_error
    ib.execDetailsEvent += on_fill

    try:
        con = resolve_contract(ib, args, logger)
    except Exception as e:
        logger.error("[contract] failed to resolve ES contract (local_symbol=%r): %s", args.local_symbol, e)
        sys.exit(1)

    if con is None:
        logger.error("[contract] resolve_contract returned None (local_symbol=%r).", args.local_symbol)
        sys.exit(1)

    logger.info("[contract] using contract: %s (conId=%s)", getattr(con, "localSymbol", con), getattr(con, "conId", None))

    ticker: Ticker = ib.reqMktData(con, "", False, False)
    ib.sleep(1.0)

    ctx["con"] = con
    ctx["ticker"] = ticker

    net_start = int(round(compute_position(ib, con)))
    if net_start != 0 and args.place_orders:
        logger.info("[startup_protect] detected existing net position=%s", net_start)
        if not has_hedge_protection(ib, con, net_start, logger):
            last_price = ticker.last or ticker.marketPrice()
            if last_price is not None:
                attach_startup_protection(ib=ib, con=con, net=net_start, args=args, last_px=float(last_price), logger=logger)

    bars = BarBuffer(maxlen=512)

    day_risk = DayRisk(
        loss_cap_R=float(args.day_loss_cap_R),
        max_trades=int(args.max_trades_per_day),
        max_consec_losses=int(args.max_consec_losses),
        post_flat_cooldown_sec=int(args.post_flat_cooldown_sec),
    )

    # Overtrading controls (compat fields if DayRisk predates them)
    try:
        if not hasattr(day_risk, "trades_this_hour"):
            setattr(day_risk, "trades_this_hour", 0)
        if not hasattr(day_risk, "hour_key"):
            setattr(day_risk, "hour_key", "")
        if not hasattr(day_risk, "last_loss_ts"):
            setattr(day_risk, "last_loss_ts", 0.0)
    except Exception:
        pass

    try:
        setattr(day_risk, "max_trades_per_hour", int(getattr(args, "max_trades_per_hour", 3)))
    except Exception:
        pass
    try:
        setattr(day_risk, "post_loss_cooldown_sec", int(getattr(args, "post_loss_cooldown_sec", 600)))
    except Exception:
        pass

    week_state: WeekState = default_week_state(args.day_loss_cap_R, args.weekly_cap_mult)

    bandit = load_thompson(LEARN_MODEL_PATH)
    if bandit is None:
        bandit = ThompsonGaussian.new(DEFAULT_ARMS, gamma=0.01, sigma2=1.0)
        logger.info("[bandit] initialized new ThompsonGaussian model")
        try:
            save_thompson(LEARN_MODEL_PATH, bandit)
        except Exception as e:
            logger.error("[bandit] failed to save initial state: %s", e)
    else:
        logger.info("[bandit] loaded ThompsonGaussian state from disk")

    meta = MetaLearner()

    shadow = ShadowSim(
        model_path=SHADOW_MODEL_JSON,
        roundtrips_csv=SHADOW_ROUNDTRIP_LOG,
        es_multiplier=50.0,
        model_min_trades=20,
        model_lookback_days=30,
    )
    logger.info("[shadow] ShadowSim initialized (model=%s, rts=%s)", SHADOW_MODEL_JSON, SHADOW_ROUNDTRIP_LOG)

    try:
        setattr(shadow, "max_roundtrips_per_day", int(getattr(args, "shadow_max_roundtrips_per_day", 60)))
        setattr(shadow, "max_roundtrips_per_hour", int(getattr(args, "shadow_max_roundtrips_per_hour", 8)))
        setattr(shadow, "post_close_cooldown_sec", int(getattr(args, "shadow_post_close_cooldown_sec", 30)))
        setattr(shadow, "post_loss_cooldown_sec", int(getattr(args, "shadow_post_loss_cooldown_sec", 120)))
    except Exception:
        pass

    trade_start = utils.parse_ct_time(args.trade_start_ct)
    trade_end = utils.parse_ct_time(args.trade_end_ct)
    _ = utils.parse_ct_list(args.session_reset_cts)

    day_date = utils.ct_now().date()
    caps_reset_date: Optional[dt.date] = None
    bayes_ran_today = False
    safety_halt_for_today = False
    safety_last_ts: Optional[dt.datetime] = None

    equity: float = 100000.0
    equity_hwm: float = equity
    hwm_factor: float = 1.0
    last_acct_netliq: Optional[float] = None

    trades_today = 0
    total_trades = 0
    running_pnl_today = 0.0
    wins_today = 0
    losses_today = 0
    last_trade_close_ts: Optional[float] = None
    last_acct_realized: Optional[float] = None

    pos_entry_ct: Optional[dt.datetime] = None
    current_arm: Optional[str] = None
    current_side: Optional[str] = None
    last_signal_arm: Optional[str] = None
    last_signal_side: Optional[str] = None
    last_regime: str = "unknown"

    (
        day_date,
        trades_today,
        running_pnl_today,
        wins_today,
        losses_today,
        equity,
        equity_hwm,
        last_acct_netliq,
        last_regime,
    ) = restore_runtime_into_objects(
        runtime_state_json=RUNTIME_STATE_JSON,
        logger=logger,
        bars=bars,
        day_risk=day_risk,
        week_state=week_state,
        meta=meta,
        default_day_date=day_date,
        default_trades_today=trades_today,
        default_running_pnl_today=running_pnl_today,
        default_wins_today=wins_today,
        default_losses_today=losses_today,
        default_equity=equity,
        default_equity_hwm=equity_hwm,
        default_last_acct_netliq=last_acct_netliq,
        default_last_regime=last_regime,
    )

    # Re-check & repair after restore (in case another process wrote junk during crash/restart)
    _repair_trades_csv_if_needed(TRADE_LOG_CSV, logger)
    _ensure_csv_header(TRADE_LOG_CSV, "timestamp,side,qty,entry_px,exit_px,pnl,R,tags")

    try:
        if os.path.exists(TRADE_LOG_CSV):
            with open(TRADE_LOG_CSV, "r", encoding="utf-8", newline="") as f:
                total_trades = sum(1 for _ in csv.DictReader(f))
    except Exception as e:
        logger.error("[startup] failed to seed total_trades: %s", e)

    try:
        today_ct = utils.ct_now().date()
        day_date = today_ct
        trades_today, running_pnl_today, wins_today, losses_today, rebuilt_day_R = recompute_intraday_from_trades(
            TRADE_LOG_CSV, today_ct, logger=logger
        )
        try:
            day_risk.day_R = float(rebuilt_day_R)
        except Exception:
            pass
    except Exception as e:
        logger.error("[startup] intraday rebuild from trades.csv failed: %s", e)

    day_policy_state = DayPolicyState()

    class _EODState:
        def __init__(self) -> None:
            self.last_ran_date = None
            self.last_skip_log_ts = 0.0
            self.promoted_date = None

    eod_state = _EODState()

    ctx.update(
        {
            "bars": bars,
            "day_risk": day_risk,
            "week_state": week_state,
            "bandit": bandit,
            "meta": meta,
            "shadow": shadow,
            "margin_mgr": margin_mgr,
            "day_policy_state": day_policy_state,
            "eod_state": eod_state,
            "trade_start": trade_start,
            "trade_end": trade_end,
            "day_date": day_date,
            "caps_reset_date": caps_reset_date,
            "bayes_ran_today": bayes_ran_today,
            "safety_halt_for_today": safety_halt_for_today,
            "safety_last_ts": safety_last_ts,
            "equity": equity,
            "equity_hwm": equity_hwm,
            "hwm_factor": hwm_factor,
            "last_acct_netliq": last_acct_netliq,
            "trades_today": trades_today,
            "total_trades": total_trades,
            "running_pnl_today": running_pnl_today,
            "wins_today": wins_today,
            "losses_today": losses_today,
            "last_trade_close_ts": last_trade_close_ts,
            "last_acct_realized": last_acct_realized,
            "pos_entry_ct": pos_entry_ct,
            "current_arm": current_arm,
            "current_side": current_side,
            "last_signal_arm": last_signal_arm,
            "last_signal_side": last_signal_side,
            "last_regime": last_regime,
            "LAST_ORPHAN_SWEEP_TS": 0.0,
            "last_sharpe_update_ts": 0.0,
            "sharpe_R_value": 0.0,
            "last_state_save_ts": 0.0,
            "last_atr_points": 0.0,
            "last_adx_val": 0.0,

            # Shadow stats fields used by hb + loop_core
            "shadow_last_eval_ts": 0.0,
            "shadow_eval_count_today": 0,
            "last_shadow_step_ts": 0.0,
            "shadow_eod_ran_today": False,

            # Shadow rail runtime trackers (shadow_core should update these if implemented)
            "shadow_roundtrips_today": 0,
            "shadow_roundtrips_this_hour": 0,
            "shadow_hour_key": "",
            "shadow_last_close_ts": 0.0,
            "shadow_last_loss_ts": 0.0,
        }
    )

    
    # ------------------------------------------------------------------
    # Day-policy flatten hooks (NO placeholders)
    # day_policy_core.apply_day_policies() uses these.
    # ------------------------------------------------------------------
    def _flatten_all() -> None:
        try:
            if ctx.get("con") is None:
                logger.error("[flatten] ctx['con'] is None; cannot flatten")
                return
            order_core.flatten_all(ib, ctx["con"], logger=logger)
        except Exception as e:
            logger.exception("[flatten] flatten_all failed: %s", e)

    def _place_market_flat(net: int) -> None:
        try:
            if ctx.get("con") is None:
                logger.error("[flatten] ctx['con'] is None; cannot market-flat")
                return
            qty = int(abs(net))
            if qty <= 0:
                return
            side = "SELL" if net > 0 else "BUY"
            order = MarketOrder(side, qty)
            logger.warning("[flatten] market-flat %s x%s", side, qty)
            ib.placeOrder(ctx["con"], order)
        except Exception as e:
            logger.exception("[flatten] place_market_flat failed: %s", e)

    ctx["flatten_all"] = _flatten_all
    ctx["place_market_flat"] = _place_market_flat

    # Fail-fast wiring validation (refuse to run with placeholders/missing hooks)
    assert_ctx_wiring(ctx)

    logger.info("Entering main loop (loop_core.run_loop_iteration)...")
    # wire required callback for pt_loop_exec
    ctx.setdefault("build_signal_and_bands", build_signal_and_bands)

    while True:
        ctx = run_loop_iteration(ctx)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Exiting...")
        sys.exit(0)
