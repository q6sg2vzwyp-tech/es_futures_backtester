@echo off
setlocal

REM Always delegate to PowerShell script (single source of truth).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_bot.ps1"

endlocal
