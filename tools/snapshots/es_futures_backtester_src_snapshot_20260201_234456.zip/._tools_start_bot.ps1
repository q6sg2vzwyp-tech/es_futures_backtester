Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ROOT = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$PY   = Join-Path $ROOT ".venv\Scripts\python.exe"
$WD   = Join-Path $ROOT "watchdog_single.py"
$RUN  = Join-Path $ROOT "run"
$LOCK = Join-Path $RUN  "start_bot.lock"
$LOGO = Join-Path $RUN  "watchdog_detached.out.log"
$LOGE = Join-Path $RUN  "watchdog_detached.err.log"

$WD_PIDLOCK = Join-Path $RUN "watchdog_single.pidlock"
$WD_LOCK    = Join-Path $RUN "watchdog_single.lock"

New-Item -ItemType Directory -Force -Path $RUN | Out-Null

# Clear stale shutdown flag so bot doesn't instantly stop
Remove-Item (Join-Path $RUN "SHUTDOWN.flag") -Force -ErrorAction SilentlyContinue

function Get-WatchdogPidFromPidlock {
  param([string]$PidlockPath)
  try {
    if (!(Test-Path $PidlockPath)) { return $null }
    $txt = (Get-Content -LiteralPath $PidlockPath -ErrorAction Stop | Select-Object -First 1).Trim()
    if ($txt -match '^\d+$') { return [int]$txt }
    return $null
  } catch { return $null }
}

function Test-PidAlive {
  param([int]$Pid)
  try {
    if ($Pid -le 0) { return $false }
    $p = Get-Process -Id $Pid -ErrorAction Stop
    return $true
  } catch { return $false }
}

function Test-StartBotRunning {
  param([string]$RootPath)
  @(
    Get-CimInstance Win32_Process |
      Where-Object {
        $_.Name -in @("powershell.exe","pwsh.exe") -and
        $_.CommandLine -like "*start_bot.ps1*" -and
        $_.CommandLine -like "*$RootPath*"
      }
  ).Count -gt 0
}

# --- atomic single-instance guard for the launcher itself ---
# Fix stale-lock bricking: if lock exists but no start_bot is running, remove and retry once.
$fs = $null
$sw = $null
for ($attempt=1; $attempt -le 2; $attempt++) {
  try {
    $fs = [System.IO.File]::Open($LOCK, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
    $sw = New-Object System.IO.StreamWriter($fs)
    $sw.WriteLine("pid=$PID ts=$(Get-Date -Format o)")
    $sw.Flush()
    break
  } catch {
    if ($attempt -eq 1) {
      if (-not (Test-StartBotRunning -RootPath $ROOT)) {
        Remove-Item $LOCK -Force -ErrorAction SilentlyContinue
        continue
      }
    }
    Write-Host "[START] Another start_bot is already running (lock exists): $LOCK"
    exit 2
  }
}

try {
  # Robust "already running" detection: prefer watchdog pidlock/lock over process scan (avoids start race)
  $pidFromLock = Get-WatchdogPidFromPidlock -PidlockPath $WD_PIDLOCK
  if ($pidFromLock -and (Test-PidAlive -Pid $pidFromLock)) {
    Write-Host "[START] watchdog already running (pidlock): $pidFromLock"
    exit 2
  }

  if (Test-Path $WD_LOCK) {
    # lock exists but pidlock missing or dead: stale lock, clear it
    Remove-Item $WD_LOCK -Force -ErrorAction SilentlyContinue
    Remove-Item $WD_PIDLOCK -Force -ErrorAction SilentlyContinue
  }

  # Extra sanity: if a watchdog is already running, do NOT start another.
  $existing = @(Get-CimInstance Win32_Process |
    Where-Object { $_.Name -in @('python.exe','pythonw.exe') -and $_.CommandLine -like "*$ROOT*" -and $_.CommandLine -match "watchdog_single\.py" })

  if ($existing.Count -gt 0) {
    Write-Host "[START] watchdog already running (process scan): $($existing[0].ProcessId)"
    exit 2
  }

  Write-Host ""
  Write-Host "---------------------------------------------------"
  Write-Host "  ES Paper Trader - PAPER MODE (starter)"
  Write-Host "  Root    : $ROOT"
  Write-Host "  Python  : $PY"
  Write-Host "  Watchdog: $WD"
  Write-Host "---------------------------------------------------"

  # detach watchdog; redirect to logs
  Start-Process -FilePath $PY `
    -WorkingDirectory $ROOT `
    -ArgumentList @($WD) `
    -WindowStyle Hidden `
    -RedirectStandardOutput $LOGO `
    -RedirectStandardError  $LOGE | Out-Null

  # Wait for watchdog to fully initialize and write its pidlock (closes the double-start race window)
  $deadline = (Get-Date).AddSeconds(5)
  $wdPid = $null
  while ((Get-Date) -lt $deadline) {
    Start-Sleep -Milliseconds 200
    $wdPid = Get-WatchdogPidFromPidlock -PidlockPath $WD_PIDLOCK
    if ($wdPid -and (Test-PidAlive -Pid $wdPid)) { break }
  }

  if (-not ($wdPid -and (Test-PidAlive -Pid $wdPid))) {
    Write-Host "[START][ERROR] Watchdog did not initialize (no live pidlock). Check:"
    Write-Host "  $LOGE"
    exit 1
  }

  Write-Host "[START] Watchdog launched (pid=$wdPid)."
  exit 0
}
finally {
  try { if ($sw) { $sw.Dispose() } } catch {}
  try { if ($fs) { $fs.Dispose() } } catch {}
  try { Remove-Item $LOCK -Force -ErrorAction SilentlyContinue } catch {}
}
