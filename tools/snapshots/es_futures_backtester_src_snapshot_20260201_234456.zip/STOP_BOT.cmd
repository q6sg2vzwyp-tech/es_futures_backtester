@echo off
setlocal EnableExtensions

cd /d "%~dp0.."
set "ROOT=%CD%"
set "RUN=%ROOT%\run"

if not exist "%RUN%" mkdir "%RUN%" >nul 2>&1
type nul > "%RUN%\SHUTDOWN.flag"

timeout /t 2 /nobreak >nul

powershell -NoProfile -Command ^
  "$procs = Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('python.exe','pythonw.exe') -and $_.CommandLine -like '*es_futures_backtester*' -and ($_.CommandLine -match 'watchdog_single\.py|paper_trader\.py|hb_monitor\.py') }; " ^
  "if($procs){ $procs | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } catch {} } }"

del /f /q "%RUN%\SHUTDOWN.flag" >nul 2>&1
exit /b 0
