@echo off
setlocal
set "ROOT=%~dp0.."
set "RUN=%ROOT%\run"
if not exist "%RUN%" mkdir "%RUN%" >nul 2>&1

echo [STOP] Writing shutdown flag...
type nul > "%RUN%\SHUTDOWN.flag"
echo [STOP] Done. Bot will exit cleanly within a few seconds.
exit /b 0
