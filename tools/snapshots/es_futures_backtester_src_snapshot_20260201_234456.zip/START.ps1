Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ROOT = Split-Path -Parent $PSScriptRoot
$RUN  = Join-Path $ROOT "run"
$CMD  = "$env:WINDIR\System32\cmd.exe"
$START_CMD = Join-Path $ROOT "tools\START_BOT.cmd"

New-Item -ItemType Directory -Force $RUN | Out-Null

# Unique log per run so Notepad never blocks startup
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LOG   = Join-Path $RUN "start_wrapper_$stamp.log"

function LogLine([string]$s) {
  try { $s | Add-Content -Encoding UTF8 $LOG } catch { }
}

LogLine "[$(Get-Date -Format s)] START wrapper: root=$ROOT"
LogLine "[$(Get-Date -Format s)] START wrapper: cmd=$CMD"
LogLine "[$(Get-Date -Format s)] START wrapper: start_cmd=$START_CMD"

# Clear stale stop-state
Remove-Item (Join-Path $RUN "SHUTDOWN.flag") -Force -ErrorAction SilentlyContinue
# NOTE: Do NOT delete watchdog_single.lock on every start.
# If you ever need to clear a stale lock, do it only when no watchdog is running.
$WDLock = Join-Path $RUN "watchdog_single.lock"
try {
  $procs = Get-CimInstance Win32_Process |
    Where-Object { $_.Name -in @("python.exe","pythonw.exe") -and $_.CommandLine -like "*watchdog_single.py*" -and $_.CommandLine -like "*es_futures_backtester*" }
  if (($procs | Measure-Object).Count -eq 0 -and (Test-Path $WDLock)) {
    # Optional: clear only if lock is old/stale (>= 6 hours)
    $ageHrs = ((Get-Date) - (Get-Item $WDLock).LastWriteTime).TotalHours
    if ($ageHrs -ge 6) { Remove-Item $WDLock -Force -ErrorAction SilentlyContinue }
  }
} catch { }

try {
  Start-Process -FilePath $CMD -WorkingDirectory $ROOT -ArgumentList "/k `"$START_CMD`"" | Out-Null
  LogLine "[$(Get-Date -Format s)] START wrapper: launched new CMD window"
}
catch {
  LogLine "[$(Get-Date -Format s)] ERROR: $($_.Exception.ToString())"
  Write-Host "START failed. Log: $LOG"
  pause
}
