@echo off
setlocal EnableExtensions

cd /d "%~dp0.."
set "ROOT=%CD%"
set "RUN=%ROOT%\run"

if not exist "%RUN%" mkdir "%RUN%" >nul 2>&1
del /f /q "%RUN%\SHUTDOWN.flag" >nul 2>&1

"%ROOT%\.venv\Scripts\python.exe" "%ROOT%\watchdog_single.py"
exit /b %ERRORLEVEL%
