@echo off
setlocal EnableExtensions

cd /d "%~dp0.."
if not exist "run" mkdir "run" >nul 2>&1

echo -----------------------------------------
echo   ES Paper Trader STARTING
echo -----------------------------------------

".\.venv\Scripts\python.exe" ".\watchdog_single.py"


echo -----------------------------------------
echo   Watchdog exited. Lock cleared.
echo -----------------------------------------

exit /b %ERRORLEVEL%
