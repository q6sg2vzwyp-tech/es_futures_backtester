@echo off
setlocal EnableExtensions
cd /d "%~dp0.."

REM Dashboard only (does NOT start/stop the bot)
".\.venv\Scripts\python.exe" ".\hb_monitor.py" --alt-screen --interval 1.0 --no-singleton

endlocal
