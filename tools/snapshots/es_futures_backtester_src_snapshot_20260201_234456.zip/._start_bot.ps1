Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ROOT = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$PY   = Join-Path $ROOT ".venv\Scripts\python.exe"
$WD   = Join-Path $ROOT "watchdog_single.py"
$RUN  = Join-Path $ROOT "run"
$LOCK = Join-Path $RUN  "start_bot.lock"
$LOGO = Join-Path $RUN  "watchdog_detached.out.log"
$LOGE = Join-Path $RUN  "watchdog_detached.err.log"

New-Item -ItemType Directory -Force -Path $RUN | Out-Null

# --- atomic single-instance guard for the launcher itself ---
try {
  $fs = [System.IO.File]::Open($LOCK, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
  $sw = New-Object System.IO.StreamWriter($fs)
  $sw.WriteLine("pid=$PID ts=$(Get-Date -Format o)")
  $sw.Flush()
} catch {
  Write-Host "[START] Another start_bot is already running (lock exists): $LOCK"
  exit 2
}

try {
  # Extra sanity: if a watchdog is already running, do NOT start another.
  $existing = @(Get-CimInstance Win32_Process |
    Where-Object { $_.Name -in @('python.exe','pythonw.exe') -and $_.CommandLine -like "*$ROOT*" -and $_.CommandLine -match "watchdog_single\.py" })

  if ($existing.Count -gt 0) {
    Write-Host "[START] watchdog already running: $($existing[0].ProcessId)"
    exit 2
  }

  Write-Host ""
  Write-Host "---------------------------------------------------"
  Write-Host "  ES Paper Trader - PAPER MODE (starter)"
  Write-Host "  Root    : $ROOT"
  Write-Host "  Python  : $PY"
  Write-Host "  Watchdog: $WD"
  Write-Host "---------------------------------------------------"

  # detach watchdog; redirect to logs
  Start-Process -FilePath $PY `
    -WorkingDirectory $ROOT `
    -ArgumentList @($WD) `
    -WindowStyle Hidden `
    -RedirectStandardOutput $LOGO `
    -RedirectStandardError  $LOGE

  Write-Host "[START] Watchdog launched."
  exit 0
}
finally {
  # release the launcher lock so future manual starts work
  try { Remove-Item $LOCK -Force -ErrorAction SilentlyContinue } catch {}
}
