Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ROOT = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location $ROOT

$RUN  = Join-Path $ROOT "run"
$FLAG = Join-Path $RUN  "SHUTDOWN.flag"

New-Item -ItemType Directory -Force -Path $RUN | Out-Null

function Get-BotProcs {
  @(
    Get-CimInstance Win32_Process |
      Where-Object {
        $_.Name -in @("python.exe","pythonw.exe") -and
        $_.CommandLine -like "*$ROOT*" -and
        $_.CommandLine -match "watchdog_single\.py|paper_trader\.py|hb_monitor\.py"
      }
  )
}

# 1) Graceful stop flag
New-Item -ItemType File -Force $FLAG | Out-Null
Write-Host "[STOP] SHUTDOWN.flag written. Waiting for bot to exit..." -ForegroundColor Cyan

# 2) Wait up to 30s
$deadline = (Get-Date).AddSeconds(30)
do {
  $p = @(Get-BotProcs)
  if ($p.Count -eq 0) { break }
  Start-Sleep -Seconds 2
} while ((Get-Date) -lt $deadline)

# 3) Force kill if still running
$p = @(Get-BotProcs)
if ($p.Count -ne 0) {
  Write-Host "[STOP] Still running after 30s. Forcing termination..." -ForegroundColor Yellow
  $p | Select-Object ProcessId, ParentProcessId, CommandLine | Format-Table -AutoSize
  foreach ($row in $p) { try { Stop-Process -Id $row.ProcessId -Force -ErrorAction SilentlyContinue } catch {} }
  Start-Sleep -Seconds 2
}

$p2 = @(Get-BotProcs)
if ($p2.Count -eq 0) {
  Write-Host "[STOP] Shutdown complete." -ForegroundColor Green
} else {
  Write-Host "[STOP] ERROR: Some processes still remain." -ForegroundColor Red
  $p2 | Select-Object ProcessId, ParentProcessId, CommandLine | Format-Table -AutoSize
}

# 4) Clean stale interlocks after stop (idempotent)
Remove-Item .\run\watchdog_single.lock -Force -ErrorAction SilentlyContinue
Remove-Item .\run\paper_trader.lock    -Force -ErrorAction SilentlyContinue
Remove-Item .\run\paper_trader.pidlock -Force -ErrorAction SilentlyContinue
Remove-Item .\run\hb_monitor.lock      -Force -ErrorAction SilentlyContinue

# 5) IMPORTANT: Remove shutdown flag so next START isn't immediately stopped
try { Remove-Item $FLAG -Force -ErrorAction SilentlyContinue | Out-Null } catch {}

exit 0
