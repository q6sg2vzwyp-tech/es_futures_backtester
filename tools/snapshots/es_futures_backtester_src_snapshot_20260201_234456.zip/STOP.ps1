Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ROOT = Split-Path -Parent $PSScriptRoot
Set-Location $ROOT

cmd /c ".\tools\STOP_BOT.cmd"
