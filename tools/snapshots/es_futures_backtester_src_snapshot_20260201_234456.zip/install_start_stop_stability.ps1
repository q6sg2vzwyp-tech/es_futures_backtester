Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$here = Get-Location
$root = $here.Path
$tools = Join-Path $root "tools"

function Copy-WithBackup([string]$src, [string]$dst) {
  if (!(Test-Path $src)) { throw "Missing: $src" }
  if (Test-Path $dst) {
    $ts = Get-Date -Format "yyyyMMdd_HHmmss"
    $bak = "$dst.BAK_$ts"
    Copy-Item $dst $bak -Force
    Write-Host "[OK] Backup: $bak"
  }
  Copy-Item $src $dst -Force
  Write-Host "[OK] Installed: $dst"
}

if (!(Test-Path $tools)) { throw "tools folder not found at: $tools" }

Copy-WithBackup (Join-Path $root "START_BOT.cmd.NEW") (Join-Path $tools "START_BOT.cmd")
Copy-WithBackup (Join-Path $root "STOP_BOT.cmd.NEW")  (Join-Path $tools "STOP_BOT.cmd")

Write-Host "`nNext:"
Write-Host "  1) .\tools\STOP_BOT.cmd"
Write-Host "  2) Start-Sleep 2"
Write-Host "  3) .\tools\START_BOT.cmd"
