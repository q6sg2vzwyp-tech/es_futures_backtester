# watchdog_single.py
# Minimal hard-singleton watchdog for Windows (named mutex) + launches paper_trader.py
# Duplicate watchdog instance exits immediately with rc=2.

from __future__ import annotations

import os
import sys
import time
import subprocess
from pathlib import Path

# ---- Windows mutex singleton (hard) ----
def _acquire_mutex_or_exit_rc2(name_base: str) -> None:
    if os.name != "nt":
        return

    import ctypes
    from ctypes import wintypes

    k32 = ctypes.WinDLL("kernel32", use_last_error=True)

    CreateMutexW = k32.CreateMutexW
    CreateMutexW.argtypes = [wintypes.LPVOID, wintypes.BOOL, wintypes.LPCWSTR]
    CreateMutexW.restype = wintypes.HANDLE

    GetLastError = k32.GetLastError
    GetLastError.restype = wintypes.DWORD

    CloseHandle = k32.CloseHandle
    CloseHandle.argtypes = [wintypes.HANDLE]
    CloseHandle.restype = wintypes.BOOL

    ERROR_ALREADY_EXISTS = 183
    ERROR_ACCESS_DENIED = 5

    name_global = "Global\\" + name_base
    name_local  = "Local\\" + name_base

    def _try(name: str):
        h = CreateMutexW(None, False, name)
        gle = int(GetLastError())
        return h, gle

    h, gle = _try(name_global)
    if not h:
        if gle == ERROR_ACCESS_DENIED:
            h, gle = _try(name_local)
        else:
            sys.stderr.write(f"[WD] Mutex create failed (GetLastError={gle}). Exiting.\n")
            sys.stderr.flush()
            raise SystemExit(2)

    if gle == ERROR_ALREADY_EXISTS:
        try:
            CloseHandle(h)
        except Exception:
            pass
        print("[WD] Another watchdog is already running. Exiting.")
        raise SystemExit(2)

    globals()["_WD_MUTEX_HANDLE"] = h  # keep alive


def _ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _log(msg: str) -> None:
    sys.stdout.write(f"{_ts()} [WD] {msg}\n")
    sys.stdout.flush()


def _read_args_file(args_file: Path) -> list[str]:
    if not args_file.exists():
        return []
    out: list[str] = []
    for line in args_file.read_text(encoding="utf-8", errors="replace").splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        out.append(s)
    return out


def main() -> int:
    _acquire_mutex_or_exit_rc2("es_futures_backtester_watchdog_single")

    base_dir = Path(__file__).resolve().parent
    trader_path = base_dir / "paper_trader.py"
    args_file = base_dir / "single.cmdline.txt"

    _log("Watchdog started.")
    _log(f"Trader target: {trader_path}")
    _log(f"Args file   : {args_file}")
    _log("-" * 50)

    py = str((base_dir / ".venv" / "Scripts" / "python.exe").resolve())
    if not Path(py).exists():
        py = sys.executable

    trader_args = _read_args_file(args_file)

    # Guardrail: refuse to launch watchdog from watchdog (if args file is wrong)
    joined = " ".join(trader_args).lower()
    if "watchdog_single.py" in joined or "watchdog_single" in joined:
        _log("Refusing to launch: args_file appears to reference watchdog_single.py")
        return 2

    cmd = [py, str(trader_path)] + trader_args

    _log("Launching paper_trader...")
    _log("CMD: " + " ".join(cmd))

    p = subprocess.Popen(cmd)
    rc = p.wait()

    _log(f"paper_trader exited (rc={rc})")

    if rc == 2:
        _log("Trader reported duplicate (rc=2). Exiting watchdog.")
        return 2

    _log("Trader exited. Exiting watchdog.")
    return int(rc) if isinstance(rc, int) else 0


if __name__ == "__main__":
    raise SystemExit(main())
