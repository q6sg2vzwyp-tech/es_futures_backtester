Overwrite watchdog_single.py with this minimal version that auto-resolves --local-symbol auto to ES front quarter (ESH/M/U/Z).
