from __future__ import annotations

# ================== EARLY SPAWN TRACE + SELFSPAWN BLOCK v1 ==================
# This block MUST be at the very top of the file (before any pt.* imports).
# It (a) logs process creation attempts very early and (b) blocks attempts to spawn another paper_trader.py
# unless you explicitly allow it with: set PT_ALLOW_SELF_SPAWN=1
# --- FORCED FORENSIC LOADER (bypasses site/sitecustomize auto-import) ---
import os as _os
if _os.environ.get("PT_FORENSIC", "0") == "1":
    try:
        import sitecustomize as _pt_sitecustomize  # noqa: F401
        print("[FORENSIC] sitecustomize forced import OK")
    except Exception as _e:
        print("[FORENSIC] sitecustomize forced import FAILED:", repr(_e))
# -----------------------------------------------------------------------

try:
    import os as _es_os, sys as _es_sys, time as _es_time, json as _es_json, traceback as _es_tb
    def _spawn_trace_write(tag, extra=None, include_stack=False):
        try:
            if _es_os.environ.get("PT_SPAWN_TRACE", "").strip().lower() not in ("1","true","yes","on"):
                return
            run_dir = _es_os.path.join(_es_os.path.dirname(__file__), "run")
            try:
                _es_os.makedirs(run_dir, exist_ok=True)
            except Exception:
                pass
            rec = {
                "ts": _es_time.strftime("%Y-%m-%d %H:%M:%S"),
                "tag": str(tag),
                "pid": _es_os.getpid(),
                "ppid": (_es_os.getppid() if hasattr(_es_os, "getppid") else None),
                "argv": _es_sys.argv[:],
            }
            if extra is not None:
                rec["extra"] = extra
            if include_stack:
                rec["stack"] = "".join(_es_tb.format_stack(limit=80))
            p = _es_os.path.join(run_dir, "spawn_trace.log")
            with open(p, "a", encoding="utf-8") as f:
                f.write(_es_json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def _selfspawn_block(reason, detail=None):
        try:
            _spawn_trace_write("SELFSPAWN_BLOCK", extra={"reason": reason, "detail": detail}, include_stack=True)
        except Exception:
            pass
        raise SystemExit(99)

    # ---- subprocess Popen / run wrappers ----
    try:
        import subprocess as _es_sp
        _es_orig_popen_init = _es_sp.Popen.__init__
        def _es_popen_init(self, *a, **k):
            try:
                cmd = ""
                if a:
                    cmd = repr(a[0])
                elif "args" in k:
                    cmd = repr(k.get("args"))
                if cmd and ("paper_trader.py" in str(cmd).lower()) and _es_os.environ.get("PT_ALLOW_SELF_SPAWN","").strip().lower() not in ("1","true","yes","on"):
                    _selfspawn_block("subprocess.Popen", detail=str(cmd))
                _spawn_trace_write("subprocess.Popen", extra={"cmd": str(cmd)}, include_stack=True)
            except SystemExit:
                raise
            except Exception:
                pass
            return _es_orig_popen_init(self, *a, **k)
        _es_sp.Popen.__init__ = _es_popen_init

        if hasattr(_es_sp, "run"):
            _es_orig_run = _es_sp.run
            def _es_run(*a, **k):
                try:
                    cmd = ""
                    if a:
                        cmd = repr(a[0])
                    elif "args" in k:
                        cmd = repr(k.get("args"))
                    if cmd and ("paper_trader.py" in str(cmd).lower()) and _es_os.environ.get("PT_ALLOW_SELF_SPAWN","").strip().lower() not in ("1","true","yes","on"):
                        _selfspawn_block("subprocess.run", detail=str(cmd))
                    _spawn_trace_write("subprocess.run", extra={"cmd": str(cmd)}, include_stack=True)
                except SystemExit:
                    raise
                except Exception:
                    pass
                return _es_orig_run(*a, **k)
            _es_sp.run = _es_run
    except Exception:
        pass

    # ---- Win32 CreateProcessW wrapper (ctypes direct spawns) ----
    try:
        import ctypes as _es_ct
        _es_k32 = _es_ct.windll.kernel32
        _es_orig_cp = _es_k32.CreateProcessW
        def _es_CreateProcessW(appName, cmdLine, *rest):
            try:
                s = (str(cmdLine) if cmdLine is not None else "")
                if ("paper_trader.py" in s.lower()) and _es_os.environ.get("PT_ALLOW_SELF_SPAWN","").strip().lower() not in ("1","true","yes","on"):
                    _selfspawn_block("CreateProcessW", detail=s)
                _spawn_trace_write("kernel32.CreateProcessW", extra={"appName": str(appName), "cmdLine": s}, include_stack=True)
            except SystemExit:
                raise
            except Exception:
                pass
            return _es_orig_cp(appName, cmdLine, *rest)
        _es_k32.CreateProcessW = _es_CreateProcessW
    except Exception:
        pass

    _spawn_trace_write("BOOT_TOP", extra={"note":"early tracer active"}, include_stack=False)
except Exception:
    pass
# ================== END EARLY SPAWN TRACE + SELFSPAWN BLOCK ==================
import os
import time
import json
import math
import datetime as dt
from pt.timeutils import ct_now, parse_hhmm
from pt.ai_hooks import AIHooks
from pt.learner import ThompsonGaussian, learner_paths, load_thompson, save_thompson, set_log as learner_set_log
from pt.day_state import load_json as _day_load_json, save_json as _day_save_json, ensure_entry as _day_ensure_entry
from zoneinfo import ZoneInfo
from typing import Any, Dict, Optional, List, Tuple
from ib_insync import IB, Contract, Trade, Order, MarketOrder, LimitOrder, Future

# --- SAFE_IBINSYNC_CONTRACTDETAILS_PATCH ---
# ib_insync can throw KeyError in Wrapper.contractDetails if late/stale contractDetails messages
# arrive after a disconnect/reconnect and the reqId is no longer tracked in _results.
# We ignore those stale messages to keep the event loop stable, but otherwise preserve normal behavior.
try:
    from ib_insync.wrapper import Wrapper as _IBW_Wrapper  # type: ignore

    _orig_contractDetails = getattr(_IBW_Wrapper, "contractDetails", None)

    def _safe_contractDetails(self, reqId, contractDetails):
        try:
            rid = int(reqId)
        except Exception:
            rid = reqId
        try:
            # If the request is no longer tracked, ignore (stale/late)
            results = getattr(self, "_results", {})
            if isinstance(results, dict) and (int(rid) not in results):
                return
        except Exception:
            # If we can't inspect state, just fall back to original
            pass

        # Normal path: call original implementation
        try:
            if callable(_orig_contractDetails):
                return _orig_contractDetails(self, reqId, contractDetails)
        except Exception:
            return

    if callable(_orig_contractDetails):
        _IBW_Wrapper.contractDetails = _safe_contractDetails  # type: ignore[attr-defined]
except Exception:
    pass
# --- END SAFE_IBINSYNC_CONTRACTDETAILS_PATCH ---

def log(tag: str, **fields):
    global _FILELOG
    try:
        _FILELOG
    except Exception:
        _FILELOG = DailyFileLog(r'.\logs')
    """Minimal logger shim to keep legacy calls working during modularization."""
    try:
        parts = [f"{k}={v}" for k, v in fields.items()]
        msg = f"[{tag}] " + " ".join(parts) if parts else f"[{tag}]"
        print(msg, flush=True)
        try: _FILELOG.write(msg)
        except Exception: pass
    except Exception:
        try:
            print(f"[{tag}] {fields}", flush=True)
        except Exception:
            pass

from pt.ib_connect import connect_existing_ib_from_args
from pt.week_guard import init_week_state, weekly_reset_if_needed, add_week_reward, weekly_cap_hit
from pt.simple_filelog import DailyFileLog
from pt.execution import flatten_market, promote_parent_limit_to_market
    # (removed) legacy singleton guard
# ================== SINGLETON (CENTRALIZED) ==================
# Single source of truth lives in: pt/singleton.py
# This block must run before any pt.* imports that might have side-effects.
try:
    import os as _osSS
    if _osSS.environ.get("PT_SINGLETON_PID", "") != str(_osSS.getpid()):
        from pt.singleton import acquire_or_exit as _pt_acquire_or_exit  # noqa
        _PT_SINGLETON_HANDLE = _pt_acquire_or_exit(app_name="paper_trader")
        _osSS.environ["PT_SINGLETON_PID"] = str(_osSS.getpid())
except SystemExit:
    raise
except Exception:
    # Never let singleton errors crash unexpectedly here; acquire_or_exit exits rc=2 on duplicates.
    pass
# ================== END SINGLETON (CENTRALIZED) ==================
from pt.spawn_trace import spawn_trace_write as _spawn_trace_write


# --------------------------------------


# Mark any children we launch from THIS process (if any)

# ==========================================================


# --- pt modules (NO side effects; import only after singleton lock acquired) ---
from pt.heartbeat import init_heartbeat, hb_update, start_heartbeat_thread
from pt.contracts import mk_contract as pt_mk_contract, contract_multiplier as pt_contract_multiplier
# Add these only when the modules exist:
# from pt.args import build_argparser
# from pt.ib_connect import connect_with_retries
# from pt.contracts import mk_contract, contract_multiplier
# from pt.orders import ...
# from pt.risk import ...
# from pt.loop import ...
# ---------------------------------------------------------------------------

# ==========================================================================

# ========================= Margin / Funds Snapshot =========================
# (moved to pt/margin.py)
from pt.margin import MarginSnap, margin_snap, refresh_available_funds, refresh_per_contract_margin
# =============================================================================

def _shadow_learn_on_veto(
    chosen_arm: str,
    reason: str,
    reward: float = 0.0,
    learner=None,
    strat_path: str | None = None,
    args=None,
):
    """
    Shadow learning hook for veto/caps cases.

    - Always logs the veto.
    - If --learn-while-capped is enabled and learn_mode is advisory/control,
      we update the strategy learner with the given reward (usually 0.0).
    """
    try:
        if not chosen_arm:
            return

        # Always log the veto
        log("shadow_learn_capped", arm=chosen_arm, reason=reason, reward=reward)

        # No learner or no args => nothing else to do
        if learner is None or args is None:
            return

        # Only learn if the flag is on
        if not getattr(args, "learn_while_capped", False):
            return

        # Only meaningful in advisory/control; in pure shadow mode we already don't place orders
        if getattr(args, "learn_mode", "advisory") not in ("advisory", "control"):
            return

        # Update the bandit with the shadow reward (usually 0)
        learner.update(chosen_arm, reward)

        # Persist to disk if we have a path
        if strat_path:
            save_thompson(strat_path, learner)

    except Exception:
        # Never let learning break the main loop
        pass

# ---------- Self-backup on start ----------
from pt.self_backup import self_backup as _pt_self_backup

def self_backup():
    # kept for compatibility (calls centralized implementation)
    return _pt_self_backup(__file__, log_fn=print)


# ---------- Math / indicators ----------
from pt.indicators import ema as ema, atr as atr  # centralized
# ---------- Session helpers ----------
from pt.session import (
    parse_ct_list,
    within_session,
    parse_blackouts,
    in_tod_blackout,
    session_key_multi,
    reset_due_multi,
)


# ---------- Heartbeat ----------
# Heartbeat is centralized in pt.heartbeat (do not shadow it here).
# ---------- AI hooks (moved to pt.ai_hooks) ----------
# ---------- Thompson learner (moved to pt.learner) ----------
# ---------- VWAP ----------
class SessionVWAP:
    def __init__(self):
        self.pv = 0.0
        self.v = 0.0
        self.vwap = float("nan")

    def reset(self):
        self.pv = 0.0
        self.v = 0.0
        self.vwap = float("nan")

    def update_bar(self, close_px: Optional[float], volume: Optional[float]):
        try:
            if close_px is None or volume is None:
                return
            vol = max(0.0, float(volume))
            if vol <= 0:
                return
            px = float(close_px)
            self.pv += px * vol
            self.v += vol
            if self.v > 0:
                self.vwap = self.pv / self.v
        except Exception:
            pass


# ---------- IB helpers ----------
ACTIVE_STATUSES = {
    "Submitted",
    "PreSubmitted",
    "ApiPending",
    "PendingSubmit",
    "PendingCancel",
}
CANCELLABLE_STATUSES = {"Submitted", "PreSubmitted", "ApiPending", "PendingSubmit"}


def is_our_order_or_trade(obj) -> bool:
    """
    True if this order/trade belongs to this script's clientId.
    When ACTIVE_CLIENT_ID is None (before connect), we treat everything as ours.
    """
    try:
        if ACTIVE_CLIENT_ID is None:
            return True
        o = getattr(obj, "order", obj)
        cid = getattr(o, "clientId", None)
        return cid == ACTIVE_CLIENT_ID
    except Exception:
        return False


def list_open_orders_for_contract(ib: IB, con: Contract) -> List[Trade]:
    """
    Return all *open trades* for this contract that belong to our clientId.
    """
    out: List[Trade] = []
    try:
        for t in ib.openTrades():
            if not is_our_order_or_trade(t):
                continue
            if getattr(t.contract, "conId", None) != con.conId:
                continue
            st = (t.orderStatus.status or "").strip()
            if st in ACTIVE_STATUSES:
                out.append(t)
    except Exception as e:
        log("list_open_orders_err", err=str(e))
    return out


def _classify_order_leg(order) -> str:
    try:
        ot = (getattr(order, "orderType", "") or "").upper()
        parent_id = getattr(order, "parentId", None)
        if parent_id in (None, 0):
            return "parent"
        if ot.startswith("STP"):
            return "stop"
        if ot == "LMT":
            return "take_profit"
    except Exception:
        pass
    return "child"


def _order_log_fields(order) -> Dict[str, Any]:
    return {
        "order_type": (getattr(order, "orderType", "") or "").upper() or None,
        "side": (getattr(order, "action", "") or "").upper() or None,
        "qty": float(getattr(order, "totalQuantity", 0) or 0),
        "parent_id": getattr(order, "parentId", None),
        "oca_group": (getattr(order, "ocaGroup", "") or "").strip() or None,
        "transmit": getattr(order, "transmit", None),
        "order_ref": getattr(order, "orderRef", None),
        "perm_id": getattr(order, "permId", None),
        "client_id": getattr(order, "clientId", None),
        "leg": _classify_order_leg(order),
    }


def safe_cancel(ib: IB, trade: Trade, note: str = "") -> bool:
    """
    Cancel a single trade's order, logging any errors.
    Only cancels if the order is in an active/cancellable state.

    Returns True if the order was already inactive or if a cancel request was
    submitted to IB.  Returns False if the order is still active and no cancel
    request could be issued.
    """
    meta = {}
    try:
        order = trade.order
        meta = {
            "orderId": getattr(order, "orderId", None),
            **_order_log_fields(order),
            "reason": note,
        }
        st = (trade.orderStatus.status or "").strip()
        if st in CANCELLABLE_STATUSES:
            ib.cancelOrder(order)
            log("order_cancel", status=st, **meta)
            return True
        # Treat already-done orders as a success so callers can clear tracking.
        if st not in ACTIVE_STATUSES:
            log("order_cancel_skip", status=st, already_done=True, **meta)
            return True
        log("order_cancel_skip", status=st, already_done=False, **meta)
    except Exception as e:
        meta.setdefault("reason", note)
        log("order_cancel_err", err=str(e), **meta)
    return False


def _parse_ib_date(s: str) -> Optional[dt.date]:
    """Parse IB lastTradeDateOrContractMonth formats: YYYYMM, YYYYMMDD, YYYYMMDDHH:MM:SS."""
    try:
        s = (s or "").strip()
        if not s:
            return None
        if len(s) == 6 and s.isdigit():
            return dt.date(int(s[0:4]), int(s[4:6]), 1)
        if len(s) == 8 and s.isdigit():
            return dt.datetime.strptime(s, "%Y%m%d").date()
        if len(s) >= 17 and s[0:8].isdigit() and ":" in s:
            return dt.datetime.strptime(s[0:17], "%Y%m%d%H:%M:%S").date()
        digits = "".join(ch for ch in s if ch.isdigit())
        if len(digits) >= 8:
            return dt.datetime.strptime(digits[0:8], "%Y%m%d").date()
        return None
    except Exception:
        return None
def _patch_pt_contracts():
    # no-op: pt.contracts owns contract resolution
    return



def ib_position_truth(ib: IB, con: Contract) -> Tuple[int, Optional[float]]:
    try:
        qty = 0
        avg = None
        for p in ib.positions():
            if getattr(p.contract, "conId", None) == con.conId:
                qty += int(round(p.position))
                avg = float(p.avgCost)
        return qty, avg
    except Exception:
        return 0, None


def has_active_parent_entry(ib: IB, con: Contract) -> bool:
    """
    Return True only if there is a *working* parent LIMIT entry order
    for this contract, belonging to *this* clientId.

    Conditions:
      - Order is in ib.openOrders() (i.e. actually working in TWS)
      - Status in a narrow set of active statuses
      - parentId is None/0 (i.e. not a child)
      - LMT order
      - BUY or SELL
    """
    try:
        # Only our own open orders
        open_ids = {o.orderId for o in ib.openOrders() if is_our_order_or_trade(o)}
        if not open_ids:
            return False

        WORKING_PARENT_STATUSES = {
            "Submitted",
            "PreSubmitted",
            "ApiPending",
            "PendingSubmit",
        }

        for t in ib.openTrades():
            if not is_our_order_or_trade(t):
                continue

            oid = t.order.orderId

            # Must be one of our open orders
            if oid not in open_ids:
                continue

            # Must be this contract
            if getattr(t.contract, "conId", None) != con.conId:
                continue

            st = (t.orderStatus.status or "").strip()
            if st not in WORKING_PARENT_STATUSES:
                continue

            # Parent only (children have parentId set)
            if t.order.parentId not in (None, 0):
                continue

            # Must be a limit entry
            if (t.order.orderType or "").upper() != "LMT":
                continue

            act = (t.order.action or "").upper()
            if act not in ("BUY", "SELL"):
                continue

            # If we got here, we truly have a live parent entry from this script
            return True

    except Exception as e:
        log("has_active_parent_err", err=str(e))

    return False


def cancel_siblings_for_trade(ib: IB, trade: Trade, con: Contract):
    """
    IMPORTANT: Only operates on OCA groups.

    - If the filled order has an OCA group, cancel the other orders in that same group.
    - If there is no OCA group (e.g., parent entry), DO NOTHING.
      This avoids accidentally sweeping protective stops/TPs when the entry fills.
    """
    try:
        if not is_our_order_or_trade(trade):
            return

        ocag = (trade.order.ocaGroup or "").strip()
        if not ocag:
            # Parent entry or non-OCO order: do NOT touch siblings.
            return

        for t in ib.openTrades():
            if not is_our_order_or_trade(t):
                continue
            if getattr(t.contract, "conId", None) != con.conId:
                continue
            if (t.order.ocaGroup or "").strip() == ocag:
                if t.order.orderId != trade.order.orderId:
                    meta = _order_log_fields(t.order)
                    log(
                        "sibling_cancel_request",
                        orderId=getattr(t.order, "orderId", None),
                        reason=f"[sibling OCA={ocag}]",
                        **meta,
                    )
                    safe_cancel(ib, t, note=f"[sibling OCA={ocag}]")
    except Exception as e:
        log("sibling_cancel_err", err=str(e))


def reconcile_orphans(ib: IB, account: str, con: Contract):
    try:
        qty, _ = ib_position_truth(ib, con)
        if qty != 0:
            return
        for t in ib.openTrades():
            if not is_our_order_or_trade(t):
                continue
            if getattr(t.contract, "conId", None) != con.conId:
                continue
            st = (t.orderStatus.status or "").strip()
            if st in {"Submitted", "PreSubmitted"}:
                ot = (t.order.orderType or "").upper()
                if ot in {"LMT", "STP", "STP LMT"} and (
                    t.order.parentId not in (None, 0) or t.order.ocaGroup
                ):
                    safe_cancel(ib, t, note="[ORPHAN SWEEP]")
    except Exception as e:
        log("orphan_sweep_err", err=str(e))


# ---------- Risk & sizing ----------
from pt.risk_engine import DayRisk

from pt.sizing import determine_order_qty as sizing_determine_order_qty
def iso_week_id(d: dt.date) -> str:
    y, w, _ = d.isocalendar()
    return f"{y}-W{int(w):02d}"
def decay_factor_from_half_life(hl_trades: float) -> float:
    hl = max(1.0, float(hl_trades))
    return math.exp(math.log(0.5) / hl)


# ---------- News helpers ----------
def parse_news_blackouts(spec: str) -> List[Tuple[dt.time, dt.time]]:
    return parse_blackouts(spec)


def read_news_file_flag(path: str) -> Tuple[bool, Optional[dt.datetime]]:
    try:
        if not path:
            return False, None
        path = path.strip().strip('"').strip("'")
        if not os.path.exists(path):
            return False, None
        with open(path, "r", encoding="utf-8") as f:
            obj = json.load(f)
        on = bool(obj.get("on", False))
        until_s = obj.get("until")
        until = None
        if until_s:
            try:
                until = dt.datetime.strptime(until_s, "%Y-%m-%d %H:%M")
            except Exception:
                pass
        return on, until
    except Exception as e:
        log("news_file_read_err", err=str(e))
        return False, None


# ---------- Param arms parsing ----------
def parse_param_arms(spec: str) -> Dict[str, Dict[str, float]]:
    out: Dict[str, Dict[str, float]] = {}
    spec = (spec or "").strip()
    if not spec:
        return out
    for chunk in spec.split(";"):
        chunk = chunk.strip()
        if not chunk:
            continue
        try:
            name, rest = chunk.split(":", 1)
            kv: Dict[str, float] = {}
            for part in rest.split(","):
                part = part.strip()
                if not part:
                    continue
                k, v = part.split("=", 1)
                kv[k.strip()] = float(v.strip())
            out[name.strip()] = kv
        except Exception:
            pass
    return out
# ---------- Persistence for learners (moved to pt.learner) ----------
# ---------- CLI ----------
from pt.cli import build_argparser


def main():
    _spawn_trace_write("MAIN_ENTRY")
    global ACTIVE_CLIENT_ID
    self_backup()  # snapshot the file to .\backups\ at each start

    parser = build_argparser()
    args, unknown = parser.parse_known_args()
    if unknown:
        log("arg_unknown", unknown=unknown)

    # AI hooks (journaling / advisory / guardrails)
    ai = AIHooks(base_dir=r".\logs\ai", logger=log)
    learner_set_log(log)
    # Start HB immediately
    start_heartbeat_thread()
    hb_update(
        state="-",
        idle_reason="booting",
        rt_enabled=False,
        rt_status="disabled",
        rt_age_sec=None,
        rt_queue_len=0,
        bars=0,
        net_qty=0,
    )

    # Connect (with retries)
    ib = IB()

    # ---- Error logging + emergency flat if stop gets rejected ----
    def _on_err(reqId, code, msg, misc):
        """
        Central IB error handler.

        - Always logs the error (ib_error)
        - If it looks like a STOP order was rejected while we have an open
          position *without* a protective exit, do an EMERGENCY FLAT.
        """
        try:
            c = int(code)
        except Exception:
            c = None

        msg_str = str(msg or "")
        msg_lower = msg_str.lower()

        # Always log the raw error first
        try:
            log("ib_error", reqId=reqId, code=c, msg=msg_str)
        except Exception:
            print(f"[IB-ERR] {code} {msg}")

        # --- Heuristic: "stop" + "reject" in the message ⇒ potential naked risk ---
        # You can add/remove codes here if you see specific ones in your logs.
        looks_like_stop_reject = (
            ("stop" in msg_lower and "reject" in msg_lower)
        )

        if not looks_like_stop_reject:
            return

        try:
            # 1) What is our current position?
            qty_now, _ = ib_position_truth(ib, con)
            if qty_now == 0:
                # flat already – nothing to do
                return

            # 2) Do we have any protective exit orders working?
            trades = list_open_orders_for_contract(ib, con)
            exit_action = "SELL" if qty_now > 0 else "BUY"

            has_protective = any(
                (t.order.action or "").upper() == exit_action
                and (t.order.orderType or "").upper() in {"STP", "STP LMT", "LMT"}
                for t in trades
            )

            if has_protective:
                # We are *not* naked; no need to emergency flat.
                log(
                    "emergency_flat_skip",
                    reason="protective_orders_present",
                    qty=qty_now,
                    code=c,
                    msg=msg_str,
                )
                return

            # 3) No protective orders + stop rejected ⇒ EMERGENCY FLAT
            try:
                flatten_market(qty_now)
                log(
                    "emergency_flat",
                    reason="stop_rejected_no_protective",
                    qty=qty_now,
                    code=c,
                    msg=msg_str,
                )
            except Exception as e:
                log(
                    "emergency_flat_err",
                    err=str(e),
                    qty=qty_now,
                    code=c,
                    msg=msg_str,
                )

        except Exception as e:
            # Never let the error handler blow up the script
            try:
                log("ib_error_handler_err", err=str(e), orig_code=c, orig_msg=msg_str)
            except Exception:
                print(f"[IB-ERR-HANDLER] {e}")

    ib.errorEvent += _on_err

    def connect_with_retries():
        base = int(args.clientId)
        for i in range(max(1, int(args.connect_attempts))):
            cid = base + i
            try:
                print(f"[CONNECT] Attempt {i+1}/{args.connect_attempts} -> clientId={cid}")
                log("boot_progress", step="connecting")
                connect_existing_ib_from_args(ib, args, client_id=cid, logger=log)
                ib.sleep(0.6)
                if ib.isConnected():
                    print(f"Connected (clientId={cid})")
                    try:
                        accts = ib.managedAccounts()
                        print(f"[POST-CONNECT] managedAccounts: {accts}")
                    except Exception:
                        pass
                    return cid
            except Exception as e:
                print(f"[CONNECT] Failed: {repr(e)}")
                try:
                    ib.disconnect()
                except Exception:
                    pass
                ib.sleep(0.5 + 0.25 * i)
        return None

    cid = connect_with_retries()
    if cid is None:
        print("ERROR [CONNECT] Could not establish connection.")
        return

    # ---- set active clientId for all the filters ----
    ACTIVE_CLIENT_ID = cid

    # Paper-only safety
    if not args.allow_live:
        try:
            accts = ib.managedAccounts()
            acct = accts[0] if accts else None
        except Exception:
            acct = None
        bad_port = getattr(args, "port", None) not in (7497, 4002)
        bad_acct = acct is not None and not str(acct).upper().startswith("DU")
        orders_disabled = bad_port or bad_acct
        hb_update(orders_disabled_paper_safety=orders_disabled)
        if orders_disabled:
            print(
                f"[SAFE] Paper-only: refusing to trade "
                f"(port={getattr(args,'port',None)}, account={acct})."
            )
            return

    # Market data type
    try:
        ib.reqMarketDataType(3 if args.force_delayed else 1)
        print("[MD] DELAYED (3)." if args.force_delayed else "[MD] LIVE (1).")
        hb_update(rt_enabled=not args.force_delayed, rt_status=("ok" if not args.force_delayed else "disabled"))
    except Exception as e:
        print("[MD] marketDataType failed:", repr(e))

    # Contract
    # Patch pt.contracts contract resolver for robust expiry handling
    _patch_pt_contracts()

    try:
        con = pt_mk_contract(ib, args, parse_ib_date=_parse_ib_date, log_fn=print)
    except Exception as e:
        print("[CONTRACT] Error:", repr(e))
        return
    px_mult = pt_contract_multiplier(ib, con)
    print(f"[CONTRACT] Multiplier detected: {px_mult:g}")

    # Warm up L1 quotes (non-fatal)
    try:
        tkr = ib.reqMktData(con, genericTickList="", snapshot=False, regulatorySnapshot=False)
        ib.sleep(1.0)
        ib.cancelMktData(con)
        log("md_warmup", ok=True)
    except Exception as e:
        log("md_warmup_warn", err=str(e))

    # -------- PnL & NetLiq (version-safe) --------
    ib_acct = None
    ib_daily_pnl: Optional[float] = None
    ib_netliq: Optional[float] = None

    if args.use_ib_pnl:
        try:
            accts = ib.managedAccounts()
            if accts:
                ib_acct = accts[0]

                def _on_pnl(p):
                    nonlocal ib_daily_pnl
                    try:
                        ib_daily_pnl = float(getattr(p, "dailyPnL", 0.0) or 0.0)
                    except Exception:
                        pass

                ib.pnlEvent += _on_pnl
                ib.reqPnL(ib_acct, "")

                def _on_account_value(v):
                    nonlocal ib_netliq
                    try:
                        if v.tag == "NetLiquidation" and (not ib_acct or v.account == ib_acct):
                            ib_netliq = float(v.value)
                    except Exception:
                        pass

                ib.accountValueEvent += _on_account_value
            else:
                print("[IB PNL] No managed accounts; IB PnL sync disabled.")
        except Exception as e:
            print(f"[IB PNL] Failed to subscribe: {e}")

    # -------- Seed history + RT bars --------
    H: List[float] = []
    L: List[float] = []
    C: List[float] = []
    V: List[float] = []
    last_bar_ts = None
    vwap = SessionVWAP()

    def _bar_ts(b):
        return getattr(b, "time", None) or getattr(b, "date", None)

    # Historical warmup DISABLED to avoid hanging when IB sends error 366
    try:
        log("hist_seed_skipped", reason="disabled_to_avoid_error366")
        hist = []
        H.clear()
        L.clear()
        C.clear()
        V.clear()
        last_bar_ts = None
        hb_update(bars=0)
    except Exception as e:
        log("hist_seed_err", err=repr(e))

    # Subscribe RT bars
    rt = None
    rt_mode = "TRADES"
    try:
        rt = ib.reqRealTimeBars(con, 5, "TRADES", False)
        if rt is None:
            log("rt_subscribe_warn", msg="reqRealTimeBars returned None; polling may be used")
        else:
            hb_update(rt_enabled=True, rt_status="ok")
    except Exception as e:
        rt = None
        log("rt_subscribe_err", err=repr(e))

    _rt_last_seen = None
    poll_enabled = bool(args.poll_hist_when_no_rt)
    poll_iv = max(5, int(args.poll_interval_sec)) if poll_enabled else 999999
    _last_poll = 0.0

    # Risk state
    risk = DayRisk(
        args.day_loss_cap_R,
        args.max_trades_per_day,
        args.max_consec_losses,
        args.post_flat_cooldown_sec,

    )
    # --- defaults so risk restore can't crash on missing/failed load ---
    restored_day_R = 0.0
    restored_trades = 0
    restored_consec_losses = 0
    restored_week_R = 0.0
    restored_week_id = ""
    restored_source = "default"

    risk.day_R = float(restored_day_R)
    risk.trades = int(restored_trades)
    risk.consec_losses = int(restored_consec_losses)
    last_entry_bar_ts = None
    current_arm: Optional[str] = None
    entry_price: Optional[float] = None
    cycle_bracket_entry_price: Optional[float] = None
    cycle_bracket_stop_dist: Optional[float] = None
    cycle_bracket_tp_dist: Optional[float] = None
    prev_net_qty = 0
    last_exec_price: Optional[float] = None
    cycle_commission = 0.0
    in_trade_cycle = False
    cycle_entry_qty = 0
    cycle_risk_ticks: Optional[int] = None  # NEW: per-cycle risk ticks for correct R
    last_attempt_ts: Optional[float] = None  # NEW: gate entry attempts
    realized_pnl_total = 0.0
    equity = float(args.acct_base)
    equity_hwm = equity
    realized_pnl_day = 0.0
    cycle_entry_time: Optional[dt.datetime] = None
    age_forced_flat_done = False
    _wk = init_week_state(restored_week_R, restored_week_id, ct_now().date(), args)
    week_R = float(_wk["week_R"])
    week_halted = bool(_wk["week_halted"])
    last_week_id = str(_wk["last_week_id"])
    weekly_cap_R = float(_wk["weekly_cap_R"])    # Day guard persistence
    DAY_STATE_PATH = r".\data\state\day_guard.json"
    day_state_file_exists = os.path.exists(DAY_STATE_PATH)

    log(
        "risk_state_restored",
        day_R=round(risk.day_R, 3),
        trades=int(risk.trades),
        consec_losses=int(risk.consec_losses),
        week_R=round(week_R, 3),
        week_id=last_week_id,
        source="disk" if day_state_file_exists else "default",
    )

    def persist_day_state_snapshot():
        try:
            entry_local = ensure_day_state_entry(k)
            entry_local["day_realized"] = float(day_realized)
            entry_local["day_peak_realized"] = float(day_peak_realized)
            entry_local["day_R"] = float(risk.day_R)
            entry_local["trades"] = int(risk.trades)
            entry_local["consec_losses"] = int(risk.consec_losses)
            entry_local["week_R"] = float(week_R)
            entry_local["last_week_id"] = last_week_id
            save_day_state(day_state)
        except Exception as e:
            log("day_state_snapshot_err", err=str(e))

    # Adaptive cadence scaler (backs off under stress, relaxes when calm)
    cadence_scale = 1.0
    last_cadence_event = ct_now()

    # Track the currently-working parent LIMIT entry (for limit→market promotion)
    parent_entry_id: Optional[int] = None
    parent_entry_time: Optional[float] = None
    parent_promote_deadline: Optional[float] = None
    parent_missing_log_next: float = 0.0

    def reset_parent_tracking():
        nonlocal parent_entry_id, parent_entry_time, parent_promote_deadline, parent_missing_log_next
        parent_entry_id = None
        parent_entry_time = None
        parent_promote_deadline = None
        parent_missing_log_next = 0.0
        hb_update(
            parent_entry_id=None,
            parent_to_mkt_limit_sec=None,
            parent_to_mkt_age_sec=None,
            parent_to_mkt_remaining_sec=None,
        )

    # Sessions (AM/PM segmentation only)
    session_cutovers = parse_ct_list(getattr(args, "session_reset_cts", "08:30,16:00,17:00"))
    last_reset_marks: Dict[str, str] = {}

    # News kill state
    news_kill_until: Optional[dt.datetime] = None
    news_blackouts = parse_news_blackouts(args.news_blackouts)
    news_keywords = [s.strip().lower() for s in (args.news_keywords or "").split(",") if s.strip()]

    # --- IBKR News Bulletins (optional) ---
    news_kill_until_ref: Optional[dt.datetime] = None

    def _arm_news_kill(reason: str, minutes: float):
        nonlocal news_kill_until_ref
        news_kill_until_ref = ct_now() + dt.timedelta(minutes=max(1.0, float(minutes)))
        log("news_kill_armed", reason=reason, until=str(news_kill_until_ref))

    if args.news_bulletin_listen:
        try:
            def _on_news_bulletin(msgId, newsType, message, exchange):
                try:
                    text = f"{message or ''}".lower()
                    hit_kw = any(k in text for k in news_keywords) if news_keywords else False
                    if int(newsType) == 1 or hit_kw:
                        _arm_news_kill(
                            reason=f"bulletin(type={newsType})",
                            minutes=args.news_kill_minutes,
                        )
                except Exception as e:
                    log("news_bulletin_err", err=str(e))

            ib.newsBulletinEvent += _on_news_bulletin
            ib.reqNewsBulletins(True)
            log("news_bulletins_on", msg="Subscribed to IBKR news bulletins")
        except Exception as e:
            log("news_bulletins_unavailable", err=str(e))

    # Learners (with persistence)
    gamma = decay_factor_from_half_life(args.decay_half_life_trades)
    arms_enabled = [a.strip() for a in args.enable_arms.split(",") if a.strip()] or ["trend", "breakout"]

    learn_dir = os.path.abspath(getattr(args, "learn_log_dir", r".\logs\learn"))
    strat_path = learner_paths(learn_dir, "strategy_thompson")
    param_path = learner_paths(learn_dir, "param_thompson")

    learner = load_thompson(strat_path)
    if (learner is None) or (set(learner.arms) != set(arms_enabled)):
        learner = ThompsonGaussian(arms_enabled, gamma)

    param_arms = parse_param_arms(getattr(args, "param_arms", ""))
    param_learner: Optional[ThompsonGaussian] = None
    if param_arms:
        existing = load_thompson(param_path)
        if existing and set(existing.arms) == set(param_arms.keys()):
            param_learner = existing
        else:
            param_learner = ThompsonGaussian(list(param_arms.keys()), gamma)
    current_param_arm: Optional[str] = None

    # Safe, deferred sibling/orphan triggers
    sibling_cancel_needed = False
    orphan_sweep_needed = False
    weekend_sweep_done = False  # avoid spamming weekend cancels
    friday_flat_done = False    # NEW: run Friday preclose auto-flat only once
    friday_flat_last_date: Optional[dt.date] = None  # track the calendar day it last ran
    last_orphan_sweep_time = 0.0  # NEW: throttle unconditional orphan sweeps

    def _on_exec(trade, fill):
        nonlocal last_exec_price, sibling_cancel_needed, orphan_sweep_needed, parent_entry_id
        if not is_our_order_or_trade(trade):
            return
        if getattr(trade.contract, "conId", None) != con.conId:
            return
        try:
            last_exec_price = float(fill.price)
        except Exception:
            pass
        try:
            st = (trade.orderStatus.status or "").strip()
            ocag = (trade.order.ocaGroup or "").strip()
            if st in ("Filled", "PartiallyFilled"):
                if ocag:
                    sibling_cancel_needed = True
                orphan_sweep_needed = True
        except Exception:
            pass
        try:
            order = getattr(trade, "order", None)
            if order is None:
                return
            meta = {"orderId": getattr(order, "orderId", None), **_order_log_fields(order)}
            fill_qty = getattr(fill, "shares", None)
            matches_tracked = bool(
                parent_entry_id
                and (
                    meta.get("orderId") == parent_entry_id
                    or meta.get("parent_id") == parent_entry_id
                )
            )
            log(
                "ib_status",
                event="execDetails",
                status=(trade.orderStatus.status or "").strip(),
                fill_price=getattr(fill, "price", None),
                fill_qty=float(fill_qty) if fill_qty is not None else None,
                cum_qty=getattr(fill, "cumQty", None),
                avg_price=getattr(fill, "avgPrice", None),
                tracked_parent=parent_entry_id,
                matches_tracked=matches_tracked,
                **meta,
            )
        except Exception as e:
            log("ib_status_log_err", err=str(e))

    ib.execDetailsEvent += _on_exec

    def _on_status(trade):
        nonlocal sibling_cancel_needed, orphan_sweep_needed, parent_entry_id
        if not is_our_order_or_trade(trade):
            return
        if getattr(trade.contract, "conId", None) != con.conId:
            return
        try:
            st = (trade.orderStatus.status or "").strip()
            ocag = (trade.order.ocaGroup or "").strip()
            if st == "Filled":
                if ocag:
                    sibling_cancel_needed = True
                orphan_sweep_needed = True
            order = getattr(trade, "order", None)
            if order is None:
                return
            meta = {"orderId": getattr(order, "orderId", None), **_order_log_fields(order)}
            matches_tracked = bool(
                parent_entry_id
                and (
                    meta.get("orderId") == parent_entry_id
                    or meta.get("parent_id") == parent_entry_id
                )
            )
            os_obj = trade.orderStatus
            log(
                "ib_status",
                event="orderStatus",
                status=st,
                filled=getattr(os_obj, "filled", None),
                remaining=getattr(os_obj, "remaining", None),
                avgFillPrice=getattr(os_obj, "avgFillPrice", None),
                lastFillPrice=getattr(os_obj, "lastFillPrice", None),
                whyHeld=getattr(os_obj, "whyHeld", None),
                tracked_parent=parent_entry_id,
                matches_tracked=matches_tracked,
                **meta,
            )
        except Exception as e:
            log("ib_status_log_err", err=str(e))

    ib.orderStatusEvent += _on_status
    # ---------- Day guard persistence (moved core IO to pt.day_state) ----------
    def load_day_state() -> Dict[str, Any]:
        return _day_load_json(DAY_STATE_PATH, log)

    def save_day_state(data: Dict[str, Any]):
        _day_save_json(DAY_STATE_PATH, data, log)

    def ensure_day_state_entry(key: str, seed: Optional[float] = None) -> Dict[str, Any]:
        # seed = start equity for that session slice
        if seed is None:
            seed = float(getattr(args, "acct_base", 0.0) or 0.0)
        week_id = iso_week_id(ct_now().date())

        def _save(d: Dict[str, Any]):
            save_day_state(d)

        return _day_ensure_entry(
            day_state,
            key,
            start_equity=float(seed),
            week_id=str(week_id),
            save_fn=_save,
        )
    day_state = load_day_state()
    k = session_key_multi(ct_now(), session_cutovers)
    entry = ensure_day_state_entry(k)

    day_realized = float(entry["day_realized"])
    day_peak_realized = float(entry["day_peak_realized"])
    start_of_day_equity = float(entry["start_equity"])
    restored_day_R = float(entry.get("day_R", 0.0))
    restored_trades = int(entry.get("trades", 0))
    restored_consec_losses = int(entry.get("consec_losses", 0))
    restored_week_R = float(entry.get("week_R", 0.0))
    restored_week_id = str(entry.get("last_week_id", iso_week_id(ct_now().date())))
    day_guard_dollars = -float(args.day_guard_pct) * start_of_day_equity
    # Entry / place
    def place_bracket(
        go_long: bool,
        last_price: float,
        last_bar_ts_local,
        net_qty_now: int,
        signal_name: Optional[str] = None,
    ):
        nonlocal entry_price, last_entry_bar_ts, current_param_arm, cycle_risk_ticks
        nonlocal cycle_bracket_entry_price, cycle_bracket_stop_dist, cycle_bracket_tp_dist
        nonlocal parent_entry_id, parent_entry_time, last_attempt_ts  # NEW

        # ---- hard anti-burst guard (attempt spacing) ----
        now_ts = time.time()
        eff_min_gap = int(max(1, args.min_seconds_between_entries * cadence_scale))
        entry_signal = signal_name or current_arm or ("long" if go_long else "short")

        def _entry_log(event: str, **fields):
            base = {
                "signal": entry_signal,
                "cadence_scale": round(cadence_scale, 3),
                "throttle_min_gap": eff_min_gap,
                "last_attempt_ts": last_attempt_ts,
            }
            base.update(fields)
            log(event, **base)

        if last_attempt_ts is not None and (now_ts - last_attempt_ts) < eff_min_gap:
            _entry_log(
                "gate_skip",
                reason="attempt_gap",
                since_last=round(now_ts - last_attempt_ts, 3),
            )
            return
        last_attempt_ts = now_ts

        if not args.place_orders:
            _entry_log("sim_no_place", reason="--place-orders not set")
            return

        # ---- trust IB position truth: only open if truly flat ----
        qty_truth, _ = ib_position_truth(ib, con)
        if qty_truth != 0:
            _entry_log(
                "gate_skip",
                reason="non_flat_ib_truth",
                qty_truth=int(qty_truth),
                net_qty_now=int(net_qty_now),
            )
            return

        if has_active_parent_entry(ib, con):
            _entry_log("gate_skip", reason="active_parent_entry")
            return
        if (
            args.debounce_one_bar
            and last_entry_bar_ts is not None
            and last_bar_ts_local == last_entry_bar_ts
        ):
            _entry_log("gate_skip", reason="debounce_one_bar")
            return


        # ---- parameter meta-learning override (per-entry) ----
        chosen_params: Dict[str, float] = {}
        if param_learner:
            arm, _ = param_learner.choose(list(param_arms.keys()), sample=(args.learn_mode != "shadow"))
            chosen_params = param_arms.get(arm, {})
            current_param_arm = arm
            risk_ticks_local = int(chosen_params.get("risk_ticks", args.risk_ticks))
            tp_R_local = float(chosen_params.get("tp_R", args.tp_R))
            entry_slip_local = int(chosen_params.get("entry_slippage_ticks", args.entry_slippage_ticks))
        else:
            current_param_arm = None
            risk_ticks_local = args.risk_ticks
            tp_R_local = args.tp_R
            entry_slip_local = args.entry_slippage_ticks

        qty = sizing_determine_order_qty(current_net_qty=net_qty_now, risk_ticks_for_trade=risk_ticks_local, args=args, px_mult=px_mult, equity=equity, equity_hwm=equity_hwm, ib_netliq=ib_netliq)
        if qty <= 0:
            _entry_log("gate_skip", reason="qty_le_0", suggested_qty=qty)
            return

        tick = float(args.tick_size)
        slippage = ticks_to_price_delta(risk_ticks_local * 0 + entry_slip_local, tick)  # slippage based on entry_slip_local
        risk_px = ticks_to_price_delta(risk_ticks_local, tick)

        if go_long:
            entry = round_to_tick(last_price + slippage, tick)
            sl = round_to_tick(entry - risk_px, tick)
            tp = round_to_tick(entry + risk_px * float(tp_R_local), tick)
            action = "BUY"
        else:
            entry = round_to_tick(last_price - slippage, tick)
            sl = round_to_tick(entry + risk_px, tick)
            tp = round_to_tick(entry - risk_px * float(tp_R_local), tick)
            action = "SELL"

        # --- parent entry ---
        parent = LimitOrder(
            action=action,
            totalQuantity=qty,
            lmtPrice=entry,
            tif=args.tif,
            outsideRth=bool(args.outsideRth),
        )
        parent.transmit = False

        try:
            ib.placeOrder(con, parent)
            parent_id = parent.orderId
            _entry_log(
                "entry_parent_order",
                order_id=parent_id,
                side=action,
                qty=qty,
                price=entry,
                transmit=parent.transmit,
                tif=args.tif,
            )
        except Exception as e:
            _entry_log("bracket_parent_error", error=str(e), side=action, qty=qty, price=entry)
            return

        ib.sleep(0.02)  # let TWS register the parent

        exit_action = "SELL" if action == "BUY" else "BUY"
        oca = f"OCA-{int(time.time()*1000)}"

        # --- stop-loss leg ---
        stop_loss = StopOrder(
            action=exit_action,
            totalQuantity=qty,
            stopPrice=sl,
            tif=args.tif,
            outsideRth=bool(args.outsideRth),
        )
        try:
            stop_loss.triggerMethod = 2
        except Exception:
            pass
        try:
            stop_loss.parentId = parent_id
            stop_loss.ocaGroup = oca
            stop_loss.transmit = False
            stop_loss.ocaType = 1
        except Exception:
            pass

        # --- take-profit leg ---
        take_profit = LimitOrder(
            action=exit_action,
            totalQuantity=qty,
            lmtPrice=tp,
            tif=args.tif,
            outsideRth=bool(args.outsideRth),
        )
        try:
            take_profit.parentId = parent_id
            take_profit.ocaGroup = oca
            take_profit.transmit = True  # transmit whole bracket
            take_profit.ocaType = 1
        except Exception:
            pass

        # Place children
        stop_order_id = None
        try:
            ib.placeOrder(con, stop_loss)
            stop_order_id = stop_loss.orderId
            _entry_log(
                "entry_child_order",
                child="stop",
                order_id=stop_order_id,
                parent_id=parent_id,
                price=sl,
                qty=qty,
                transmit=stop_loss.transmit,
                oca_group=oca,
            )
        except Exception as e:
            _entry_log(
                "bracket_children_error",
                child="stop",
                error=str(e),
                parent_id=parent_id,
                price=sl,
                qty=qty,
            )
            return

        tp_order_id = None
        try:
            ib.placeOrder(con, take_profit)
            tp_order_id = take_profit.orderId
            _entry_log(
                "entry_child_order",
                child="take_profit",
                order_id=tp_order_id,
                parent_id=parent_id,
                price=tp,
                qty=qty,
                transmit=take_profit.transmit,
                oca_group=oca,
            )
        except Exception as e:
            _entry_log(
                "bracket_children_error",
                child="take_profit",
                error=str(e),
                parent_id=parent_id,
                price=tp,
                qty=qty,
                stop_order_id=stop_order_id,
            )
            return

        _entry_log(
            "bracket_submitted",
            side=action,
            qty=qty,
            entry=entry,
            stop=sl,
            tp=tp,
            param_arm=current_param_arm,
            params=chosen_params or None,
            parent_id=parent_id,
            stop_order_id=stop_order_id,
            tp_order_id=tp_order_id,
            oca_group=oca,
        )

        # track this parent LIMIT entry for possible limit→market promotion
        parent_entry_id = parent_id
        parent_entry_time = time.time()
        parent_promote_deadline = (
            parent_entry_time + max(1, int(args.parent_to_mkt_sec))
            if args.parent_to_mkt_sec > 0
            else None
        )

        if args.parent_to_mkt_sec > 0:
            limit_sec = max(1, int(args.parent_to_mkt_sec))
            hb_update(
                parent_entry_id=parent_entry_id,
                parent_to_mkt_limit_sec=limit_sec,
                parent_to_mkt_age_sec=0,
                parent_to_mkt_remaining_sec=limit_sec,
            )
            log(
                "parent_to_market_timer_start",
                orderId=parent_entry_id,
                limit_sec=limit_sec,
            )
        else:
            hb_update(
                parent_entry_id=parent_entry_id,
                parent_to_mkt_limit_sec=None,
                parent_to_mkt_age_sec=None,
                parent_to_mkt_remaining_sec=None,
            )

        # update local state
        entry_price = entry
        cycle_bracket_entry_price = entry
        cycle_bracket_stop_dist = abs(entry - sl)
        cycle_bracket_tp_dist = abs(tp - entry)
        last_entry_bar_ts = last_bar_ts_local
        risk.last_entry_time = time.time()
        eff_cool = int(max(1, args.strategy_cooldown_sec * cadence_scale))
        risk.cool_until = ct_now() + dt.timedelta(seconds=eff_cool)
        risk.trades += 1
        cycle_risk_ticks = risk_ticks_local  # NEW: remember ticks for this cycle
        persist_day_state_snapshot()
    # Heartbeat/timing vars
    start_ts = time.time()
    startup_bar_ts = None
    startup_bar_seen = not args.require_new_bar_after_start
    in_caps = False
    tod_blackouts = parse_blackouts(args.tod_blackouts)
   
    # Shadow learning helper for caps (avoid spamming every second)
    shadow_last_bar_ts = None

    # MAIN LOOP
    try:
        while True:
            now = ct_now()

            # Auto re-arm the Friday preclose guard once the calendar advances
            if friday_flat_done and friday_flat_last_date is not None:
                if now.date() > friday_flat_last_date:
                    friday_flat_done = False
                    log(
                        "friday_preclose_rearm",
                        last_date=str(friday_flat_last_date),
                        rearm_date=str(now.date()),
                    )
                    friday_flat_last_date = None
            # --- Weekly R reset (ISO week) ---
            _wk = weekly_reset_if_needed(
                now.date(),
                week_R=week_R,
                week_halted=week_halted,
                last_week_id=last_week_id,
                args=args,
                log=log,
            )
            week_R = float(_wk["week_R"])
            week_halted = bool(_wk["week_halted"])
            last_week_id = str(_wk["last_week_id"])
            weekly_cap_R = float(_wk["weekly_cap_R"])
            persist_day_state_snapshot()            # Adaptive cadence relaxation: after 5+ minutes calm, drift back toward 1.0
            try:
                if cadence_scale > 1.0:
                    idle_for = (now - last_cadence_event).total_seconds()
                    if idle_for >= 300:
                        old_scale = cadence_scale
                        cadence_scale = max(1.0, cadence_scale * 0.9)
                        last_cadence_event = now
                        log(
                            "cadence_relax",
                            from_scale=round(old_scale, 3),
                            to_scale=round(cadence_scale, 3),
                        )
            except Exception as e:
                log("cadence_relax_err", err=str(e))

            # Startup delay for stability
            if (time.time() - start_ts) < args.startup_delay_sec:
                hb_update(idle_reason="booting", bars=len(C))
                ib.sleep(0.5)
                continue

            # Session cutover logging / segmentation
            cutover_hit = reset_due_multi(now, session_cutovers, last_reset_marks)
            if cutover_hit:
                risk.reset()
                realized_pnl_day = 0.0
                nk = session_key_multi(now, session_cutovers)
                ensure_day_state_entry(nk, seed=float(ib_netliq or args.acct_base))
                # keep last few segments
                keys = sorted(day_state.keys())
                for old in keys[:-8]:
                    try:
                        del day_state[old]
                    except Exception:
                        pass
                save_day_state(day_state)
                k_local = nk
                # refresh day guard
                start_equity = float(day_state[k_local]["start_equity"])
                day_guard_dollars = -float(args.day_guard_pct) * start_equity
                day_realized = float(day_state[k_local]["day_realized"])
                day_peak_realized = float(day_state[k_local]["day_peak_realized"])
                in_caps = False
                if args.vwap_reset_on_session:
                    vwap.reset()
                log("daily_reset", cutover=cutover_hit)
                k = k_local  # switch active key
                persist_day_state_snapshot()

            # ---- News kill checks ----
            file_on, file_until = read_news_file_flag(args.news_file_kill)
            if file_on:
                if (file_until is None) or (now <= file_until):
                    tgt_until = file_until or (now + dt.timedelta(minutes=args.news_kill_minutes))
                    news_kill_until = max(news_kill_until or now, tgt_until)

            # TOD news blackouts from news config
            if in_tod_blackout(now, news_blackouts):
                news_kill_until = max(news_kill_until or now, now + dt.timedelta(minutes=1))

            # Clear expired bulletin-based kill window
            if news_kill_until_ref and now > news_kill_until_ref:
                news_kill_until_ref = None

            # Merge with bulletin kill (if still active)
            if news_kill_until_ref:
                news_kill_until = max(news_kill_until or now, news_kill_until_ref)

            news_kill_active = (news_kill_until is not None) and (now <= news_kill_until)
            if news_kill_active:
                try:
                    if args.news_cancel_only or args.news_flatten_on_kill:
                        c = 0
                        for t in ib.openTrades():
                            if not is_our_order_or_trade(t):
                                continue
                            st = (getattr(t.orderStatus, "status", "") or "").strip()
                            if st in ACTIVE_STATUSES:
                                safe_cancel(ib, t, note="[news_kill]")
                                c += 1
                        if c:
                            log("news_kill_cancel_working", count=c)
                    if args.news_flatten_on_kill:
                        qty_now, _ = ib_position_truth(ib, con)
                        if qty_now != 0:
                            flatten_market(qty_now)
                except Exception as e:
                    log("news_kill_action_err", err=str(e))
                hb_update(news_kill=True)
            else:
                hb_update(news_kill=False)

            # RT ingestion
            try:
                if rt and len(rt) > 0:
                    b = rt[-1]
                    ts = getattr(b, "time", None) or getattr(b, "date", None)
                    if last_bar_ts is None or (ts and ts != last_bar_ts):
                        H.append(b.high)
                        L.append(b.low)
                        C.append(b.close)
                        vol = getattr(b, "volume", None)
                        V.append(vol if vol is not None else 0.0)
                        vwap.update_bar(b.close, vol)
                        last_bar_ts = ts

                        # NEW: new-bar-after-start gating logic
                        if startup_bar_ts is None:
                            startup_bar_ts = ts
                        elif not startup_bar_seen and ts != startup_bar_ts:
                            startup_bar_seen = True

                        _rt_last_seen = time.time()
                        hb_update(bars=len(C))
            except Exception:
                pass

            # --- Determine RT freshness / starvation ---
            _now = time.time()
            rt_seen_age = (_now - _rt_last_seen) if _rt_last_seen else None

            # If we subscribed but have never seen a bar for >8s, treat as starved
            rt_starved = (rt is not None) and (_rt_last_seen is None) and ((_now - start_ts) > 8.0)

            # Fresh if we've seen a bar within staleness window
            rt_fresh = (
                (_rt_last_seen is not None)
                and (rt_seen_age is not None)
                and (rt_seen_age <= max(5, int(args.rt_staleness_sec)))
            )

            # Heartbeat update about RT state
            if rt is not None:
                hb_update(
                    rt_enabled=True,
                    rt_status=("ok" if rt_fresh else ("starved" if rt_starved else "stale")),
                    rt_age_sec=(rt_seen_age if _rt_last_seen else None),
                    rt_queue_len=(len(rt) if rt else 0),
                )
            else:
                hb_update(
                    rt_enabled=False,
                    rt_status="disabled",
                    rt_age_sec=None,
                    rt_queue_len=0,
                )

            # --- If TRADES stream is starved, try resubscribing as MIDPOINT once ---
            if rt_starved and rt_mode == "TRADES":
                try:
                    try:
                        ib.cancelRealTimeBars(rt)
                    except Exception:
                        pass
                    ib.sleep(0.2)
                    rt = ib.reqRealTimeBars(con, 5, "MIDPOINT", False)
                    rt_mode = "MIDPOINT"
                    _rt_last_seen = None
                    log("rt_resubscribe", what="MIDPOINT")
                except Exception as e:
                    log("rt_resubscribe_err", err=str(e))

            # --- Polling fallback: also poll if RT is starved or stale ---
            poll_active = bool(poll_enabled) or rt_starved or (not rt_fresh)
            if poll_active and ((_now - _last_poll) >= poll_iv):
                _last_poll = _now
                try:
                    hist = ib.reqHistoricalData(
                        con,
                        endDateTime="",
                        durationStr="60 S",
                        barSizeSetting="5 secs",
                        whatToShow=("TRADES" if rt_mode == "TRADES" else "MIDPOINT"),
                        useRTH=False,
                        keepUpToDate=False,
                    )
                    if hist:
                        last = hist[-1]
                        ts = getattr(last, "time", None) or getattr(last, "date", None)
                        if last_bar_ts is None or (ts and ts > last_bar_ts):
                            H.append(last.high)
                            L.append(last.low)
                            C.append(last.close)
                            vol = getattr(last, "volume", None)
                            V.append(vol if vol is not None else 0.0)
                            vwap.update_bar(last.close, vol)
                            last_bar_ts = ts

                            # NEW: new-bar-after-start gating logic
                            if startup_bar_ts is None:
                                startup_bar_ts = ts
                            elif not startup_bar_seen and ts != startup_bar_ts:
                                startup_bar_seen = True

                            hb_update(bars=len(C))
                            log(
                                "poll_bar",
                                time=str(ts),
                                close=last.close,
                                total=len(C),
                                mode=rt_mode,
                            )
                    else:
                        log("poll_bar_empty", note="historical returned 0 bars", mode=rt_mode)
                except Exception as e:
                    log("poll_bar_err", err=str(e))

            # Position truth
            net_qty, avg_cost_raw = ib_position_truth(ib, con)
            hb_update(net_qty=net_qty)

            # Auto-promote a stale parent LIMIT entry to MARKET

            parent_missing_log_next = promote_parent_limit_to_market(

                ib=ib,

                con=con,

                args=args,

                log=log,

                hb_update=hb_update,

                parent_entry_id=parent_entry_id,

                parent_entry_time=parent_entry_time,

                parent_promote_deadline=parent_promote_deadline,

                parent_missing_log_next=parent_missing_log_next,

                net_qty=net_qty,

                ACTIVE_STATUSES=ACTIVE_STATUSES,

                is_our_order_or_trade=is_our_order_or_trade,

                safe_cancel=safe_cancel,

                reset_parent_tracking=reset_parent_tracking,

            )

            

            # Execute deferred sibling/orphan actions
            if sibling_cancel_needed:
                sibling_cancel_needed = False
                try:
                    for t in ib.openTrades():
                        if not is_our_order_or_trade(t):
                            continue
                        if (t.orderStatus.status or "").strip() in ("Filled", "PartiallyFilled"):
                            cancel_siblings_for_trade(ib, t, con)
                except Exception as e:
                    log("sibling_cancel_deferred_err", err=str(e))
            if orphan_sweep_needed:
                orphan_sweep_needed = False
                try:
                    reconcile_orphans(ib, ib_acct or "", con)
                    # IB looked stressed enough to create orphans → slow down a bit
                    old_scale = cadence_scale
                    cadence_scale = min(cadence_scale * 1.25, 3.0)
                    last_cadence_event = now
                    log(
                        "cadence_bump",
                        source="orphan_sweep",
                        from_scale=round(old_scale, 3),
                        to_scale=round(cadence_scale, 3),
                    )
                except Exception as e:
                    log("orphan_sweep_deferred_err", err=str(e))

             # Trade-cycle transitions
            if prev_net_qty == 0 and net_qty != 0:
                in_trade_cycle = True
                # parent has done its job (filled); stop tracking the LMT→MKT timer
                reset_parent_tracking()

                cycle_commission = 0.0
                cycle_entry_qty = abs(net_qty)
                entry_price = (
                    (avg_cost_raw / px_mult)
                    if (avg_cost_raw is not None and px_mult > 0)
                    else (C[-1] if C else None)
                )
                if cycle_bracket_entry_price is None:
                    cycle_bracket_entry_price = entry_price
                if cycle_bracket_stop_dist is None and cycle_risk_ticks is not None:
                    cycle_bracket_stop_dist = ticks_to_price_delta(
                        cycle_risk_ticks, float(args.tick_size)
                    )
                if cycle_bracket_tp_dist is None and cycle_bracket_stop_dist is not None:
                    cycle_bracket_tp_dist = cycle_bracket_stop_dist * float(args.tp_R)
                cycle_entry_time = now
                age_forced_flat_done = False

            if prev_net_qty != 0 and net_qty == 0 and entry_price is not None:
                exit_px = (
                    last_exec_price
                    if last_exec_price is not None
                    else (C[-1] if C else entry_price)
                )
                signed = 1 if prev_net_qty > 0 else -1

                # Use per-cycle risk ticks (fix for param arms)
                effective_risk_ticks = (
                    cycle_risk_ticks
                    if cycle_risk_ticks is not None
                    else args.risk_ticks
                )
                pc_risk = float(effective_risk_ticks) * float(args.tick_size) * float(px_mult)
                risk_dollars_total = pc_risk * max(1, cycle_entry_qty)

                pnl_dollars = (
                    (exit_px - entry_price)
                    * px_mult
                    * signed
                    * max(1, cycle_entry_qty)
                    - cycle_commission
                )
                reward_R = (
                    (pnl_dollars / risk_dollars_total)
                    if risk_dollars_total > 0
                    else 0.0
                )

                realized_pnl_total += pnl_dollars
                realized_pnl_day += pnl_dollars
                if ib_netliq is not None and args.use_ib_pnl:
                    equity = float(ib_netliq)
                else:
                    equity = float(args.acct_base) + realized_pnl_total
                equity_hwm = max(equity_hwm, equity)

                risk.day_R += reward_R
                risk.consec_losses = (risk.consec_losses + 1) if (reward_R < 0) else 0
                if risk.consec_losses >= args.max_consec_losses:
                    risk.halted = True
                if (reward_R < 0) and not risk.halted:
                    base = int(max(1, args.strategy_cooldown_sec * cadence_scale))
                    mult = 2.0 if risk.consec_losses >= 2 else 1.0
                    tgt = ct_now() + dt.timedelta(seconds=int(base * mult))
                    if (risk.cool_until is None) or (tgt > risk.cool_until):
                        risk.cool_until = tgt
                    log(
                        "graded_cooldown",
                        base=base,
                        mult=mult,
                        consec=risk.consec_losses,
                        until=str(risk.cool_until),
                    )

                week_R = add_week_reward(week_R, reward_R)
                day_realized += pnl_dollars
                day_peak_realized = max(day_peak_realized, day_realized)
                persist_day_state_snapshot()

                try:
                    if args.learn_mode in ("advisory", "control"):
                        learner.update(current_arm or "trend", reward_R)
                        save_thompson(strat_path, learner)
                except Exception as e:
                    log("learn_update_err", err=str(e))

                try:
                    if param_learner and current_param_arm:
                        param_learner.update(current_param_arm, reward_R)
                        save_thompson(param_path, param_learner)
                except Exception as e:
                    log("param_learn_update_err", err=str(e))

                log(
                    "flat_cycle",
                    pnl=round(pnl_dollars, 2),
                    R=round(reward_R, 3),
                    comm=round(cycle_commission, 2),
                    qty=max(1, cycle_entry_qty),
                    dayR=round(risk.day_R, 3),
                    consec=risk.consec_losses,
                    equity=round(equity, 2),
                    param_arm=current_param_arm,
                )

                # Measure min_seconds_between_entries from *this* flat
                risk.last_entry_time = time.time()
                risk.last_flat_fill_ts = risk.last_entry_time

                # --- AI journaling hook ---
                try:
                    journal_ctx = {
                        "equity": round(equity, 2),
                        "equity_hwm": round(equity_hwm, 2),
                        "day_realized": round(day_realized, 2),
                        "day_peak_realized": round(day_peak_realized, 2),
                        "week_R": round(week_R, 3),
                        "risk": {
                            "day_R": round(risk.day_R, 3),
                            "trades_today": int(risk.trades),
                            "consec_losses": int(risk.consec_losses),
                            "day_loss_cap_R": float(args.day_loss_cap_R),
                        },
                        "session_key": k,
                        "symbol": getattr(con, "localSymbol", None)
                        or getattr(con, "symbol", None),
                        "params": {
                            "risk_ticks": int(effective_risk_ticks),
                            "tp_R": float(args.tp_R),
                            "tick_size": float(args.tick_size),
                            "px_mult": float(px_mult),
                        },
                    }
                    ai.log_flat_cycle(
                        context=journal_ctx,
                        pnl_dollars=pnl_dollars,
                        reward_R=reward_R,
                        param_arm=current_param_arm,
                        strat_arm=current_arm,
                    )
                except Exception as e:
                    log("ai_flat_journal_err", err=str(e))

                in_trade_cycle = False
                entry_price = None
                current_arm = None
                current_param_arm = None
                cycle_entry_qty = 0
                cycle_commission = 0.0
                cycle_entry_time = None
                age_forced_flat_done = False
                cycle_risk_ticks = None  # reset
                cycle_bracket_entry_price = None
                cycle_bracket_stop_dist = None
                cycle_bracket_tp_dist = None

            prev_net_qty = net_qty


            # IB PnL overwrite
            if args.use_ib_pnl:
                if ib_daily_pnl is not None:
                    day_realized = float(ib_daily_pnl)
                    day_peak_realized = max(day_peak_realized, day_realized)
                    persist_day_state_snapshot()
                if ib_netliq is not None:
                    equity = float(ib_netliq)
                    equity_hwm = max(equity_hwm, equity)

            # OCO rescue (ensure both stop+tp exist and correct side)
            last_px = C[-1] if C else None
            try:
                if net_qty != 0 and args.place_orders:
                    trades = list_open_orders_for_contract(ib, con)
                    exit_action = "SELL" if net_qty > 0 else "BUY"
                    has_stop = any(
                        (t.order.orderType or "").upper().startswith("STP")
                        and (t.order.action or "").upper() == exit_action
                        for t in trades
                    )
                    has_tp = any(
                        (t.order.orderType or "").upper() == "LMT"
                        and (t.order.action or "").upper() == exit_action
                        for t in trades
                    )
                    if (not has_stop) or (not has_tp):
                        existing_stop_price = None
                        existing_tp_price = None
                        for t in trades:
                            ot = (t.order.orderType or "").upper()
                            act = (t.order.action or "").upper()
                            if ot in {"LMT", "STP", "STP LMT"} and act != exit_action:
                                meta = _order_log_fields(t.order)
                                log(
                                    "oco_rescue_cancel",
                                    reason="wrong_side",
                                    orderId=getattr(t.order, "orderId", None),
                                    **meta,
                                )
                                safe_cancel(ib, t, note="[prot wrong-side]")
                            elif ot in {"LMT", "STP", "STP LMT"} and act == exit_action:
                                if existing_stop_price is None and ot.startswith("STP"):
                                    existing_stop_price = (
                                        getattr(t.order, "stopPrice", None)
                                        or getattr(t.order, "auxPrice", None)
                                    )
                                if existing_tp_price is None and ot == "LMT":
                                    existing_tp_price = getattr(t.order, "lmtPrice", None)
                                meta = _order_log_fields(t.order)
                                log(
                                    "oco_rescue_cancel",
                                    reason="refresh",
                                    orderId=getattr(t.order, "orderId", None),
                                    **meta,
                                )
                                safe_cancel(ib, t, note="[prot refresh]")

                        qty_abs = abs(int(net_qty))
                        tick = float(args.tick_size)
                        entry_basis = cycle_bracket_entry_price or entry_price
                        risk_ticks = (
                            cycle_risk_ticks if cycle_risk_ticks is not None else args.risk_ticks
                        )
                        default_stop_dist = ticks_to_price_delta(risk_ticks, tick)
                        default_tp_dist = default_stop_dist * float(args.tp_R)
                        stop_dist = cycle_bracket_stop_dist or default_stop_dist
                        tp_dist = cycle_bracket_tp_dist or default_tp_dist

                        stop_price = None
                        stop_source = None
                        if entry_basis is not None and stop_dist is not None:
                            if net_qty > 0:
                                stop_price = round_to_tick(entry_basis - stop_dist, tick)
                            else:
                                stop_price = round_to_tick(entry_basis + stop_dist, tick)
                            stop_source = "entry"
                        if stop_price is None and existing_stop_price is not None:
                            stop_price = round_to_tick(existing_stop_price, tick)
                            stop_source = "existing_child"

                        targ_price = None
                        tp_source = None
                        if entry_basis is not None and tp_dist is not None:
                            if net_qty > 0:
                                targ_price = round_to_tick(entry_basis + tp_dist, tick)
                            else:
                                targ_price = round_to_tick(entry_basis - tp_dist, tick)
                            tp_source = "entry"
                        if targ_price is None and existing_tp_price is not None:
                            targ_price = round_to_tick(existing_tp_price, tick)
                            tp_source = "existing_child"

                        if stop_price is None or targ_price is None:
                            log(
                                "oco_rebuild_skip",
                                reason="missing_entry_context",
                                stop_price=stop_price,
                                tp_price=targ_price,
                                entry_basis=entry_basis,
                                stop_dist=stop_dist,
                                tp_dist=tp_dist,
                            )
                            continue

                        oca = f"OCO-PROT-{int(time.time())}"
                        stp = StopOrder(
                        action=exit_action,
                        totalQuantity=qty_abs,
                        stopPrice=stop_price,
                        tif=args.tif,
                        outsideRth=bool(args.outsideRth),
                        )
                        try:
                            stp.triggerMethod = 2
                        except Exception:
                            pass
                        stp.ocaGroup = oca
                        stp.transmit = False
                        try:
                            stp.ocaType = 1
                        except Exception:
                            pass
                        lmt = LimitOrder(
                            action=exit_action,
                            totalQuantity=qty_abs,
                            lmtPrice=targ_price,
                            tif=args.tif,
                            outsideRth=bool(args.outsideRth),
                        )
                        lmt.ocaGroup = oca
                        lmt.transmit = True
                        try:
                            lmt.ocaType = 1
                        except Exception:
                            pass
                            stp_id = None
                            try:
                                ib.placeOrder(con, stp)
                                stp_id = getattr(stp, "orderId", None)
                                log(
                                    "oco_rebuild_child",
                                    leg="stop",
                                    orderId=stp_id,
                                    oca_group=oca,
                                    side=exit_action,
                                    price=stop_price,
                                    qty=qty_abs,
                                    source=stop_source,
                                )
                            except Exception as e:
                                log(
                                    "oco_rebuild_err",
                                    leg="stop",
                                    err=str(e),
                                    oca_group=oca,
                                    side=exit_action,
                                    price=stop_price,
                                    qty=qty_abs,
                                )
                                continue

                            tp_id = None
                            try:
                                ib.placeOrder(con, lmt)
                                tp_id = getattr(lmt, "orderId", None)
                                log(
                                    "oco_rebuild_child",
                                    leg="take_profit",
                                    orderId=tp_id,
                                    oca_group=oca,
                                    side=exit_action,
                                    price=targ_price,
                                    qty=qty_abs,
                                    source=tp_source,
                                )
                            except Exception as e:
                                log(
                                    "oco_rebuild_err",
                                    leg="take_profit",
                                    err=str(e),
                                    oca_group=oca,
                                    side=exit_action,
                                    price=targ_price,
                                    qty=qty_abs,
                                    stop_order_id=stp_id,
                                )
                                continue

                            log(
                                "oco_rebuilt",
                                side=exit_action,
                                stp=stop_price,
                                lmt=targ_price,
                                qty=qty_abs,
                                oca_group=oca,
                                stop_order_id=stp_id,
                                tp_order_id=tp_id,
                                entry_basis=entry_basis,
                                stop_dist=stop_dist,
                                tp_dist=tp_dist,
                                stop_source=stop_source,
                                tp_source=tp_source,
                            )
            except Exception as e:
                log("oco_rescue_err", err=str(e))

            # Position-age cap
            if (
                net_qty != 0
                and (entry_price is not None)
                and (cycle_entry_time is not None)
                and (args.pos_age_minR is not None)
            ):
                elapsed = (now - cycle_entry_time).total_seconds()
                if elapsed >= max(1, int(args.pos_age_cap_sec)) and not age_forced_flat_done:
                    if last_px is not None and not math.isnan(last_px):
                        side = 1 if net_qty > 0 else -1
                        eff_ticks_for_age = cycle_risk_ticks if cycle_risk_ticks is not None else args.risk_ticks
                        pc_risk_age = float(eff_ticks_for_age) * float(args.tick_size) * float(px_mult)
                        uR = 0.0
                        if pc_risk_age > 0:
                            uR = (
                                (last_px - entry_price)
                                * px_mult
                                * side
                                * max(1, cycle_entry_qty)
                            ) / (pc_risk_age * max(1, cycle_entry_qty))
                        if uR < float(args.pos_age_minR):
                            flatten_market(net_qty)
                            age_forced_flat_done = True
                            eff_cool = int(max(1, args.strategy_cooldown_sec * cadence_scale))
                            risk.cool_until = ct_now() + dt.timedelta(seconds=eff_cool)
                            log(
                                "pos_age_forced_flat",
                                uR=round(uR, 3),
                                elapsed=int(elapsed),
                                cooldown_sec=eff_cool,
                            )

            # Weekly cap gating
            if weekly_cap_hit(week_R, weekly_cap_R):
                week_halted = True
            # Peak DD guard + caps
            caps_reasons: List[str] = []
            if risk.day_R <= -abs(args.day_loss_cap_R):
                caps_reasons.append("dayR_cap")
            if risk.trades >= args.max_trades_per_day:
                caps_reasons.append("max_trades")
            if risk.halted:
                caps_reasons.append("risk_halted")

            # only check minus_pct_guard if day_guard_pct > 0
            if args.day_guard_pct > 0 and day_realized <= day_guard_dollars:
                caps_reasons.append("minus_pct_guard")

            if weekly_cap_hit(week_R, weekly_cap_R):
                caps_reasons.append("weekly_cap_R")
            if news_kill_active:
                caps_reasons.append("news_kill")

            # Determine base state (before weekend/TOD overrides)
            if caps_reasons:
                state = "caps"
            elif args.require_rt_before_trading and not rt_fresh:
                state = "wait_rt"
            else:
                state = "active" if within_session(now, args.trade_start_ct, args.trade_end_ct) else "sleep"

            # --- Friday ~15:55 CT preclose auto-flat (safety) ---
            try:
                d_pre = now.weekday()          # Monday=0 ... Friday=4
                t_pre = now.time()

                if (
                    not friday_flat_done
                    and d_pre == 4  # Friday
                    and parse_hhmm("15:55") <= t_pre < parse_hhmm("16:00")
                ):
                    # 1) If we have a position, flatten it to MARKET
                    if net_qty != 0:
                        flatten_market(net_qty)
                        log("friday_preclose_flat", qty=net_qty, t=str(now))

                    # 2) Cancel all working orders from this script
                    cancelled = 0
                    for tr in ib.openTrades():
                        if not is_our_order_or_trade(tr):
                            continue
                        st = (getattr(tr.orderStatus, "status", "") or "").strip()
                        if st in ACTIVE_STATUSES:
                            safe_cancel(ib, tr, note="[friday_preclose]")
                            cancelled += 1
                    if cancelled:
                        log("friday_preclose_cancel", count=cancelled)

                    # 3) Halt NEW entries after auto-flat
                    risk.halted = True
                    risk.cool_until = now + dt.timedelta(minutes=60)
                    log(
                        "friday_preclose_cap",
                        cool_until=str(risk.cool_until),
                        weekday=now.weekday(),
                    )

                    # Only run once per Friday (track the day it tripped)
                    friday_flat_done = True
                    friday_flat_last_date = now.date()

            except Exception as e:
                log("friday_preclose_err", err=str(e))

            # ES 24x5 guard (Fri 16:00 → Sun 17:00 = sleep)
            d = now.weekday()  # Monday=0 ... Sunday=6
            t = now.time()

            weekend_reason = ""

            if d == 4 and t >= parse_hhmm("16:00"):      # Friday after 16:00
                state = "sleep"
                weekend_reason = "fri_after_1600"
            elif d == 5:                                 # Saturday
                state = "sleep"
                weekend_reason = "saturday"
            elif d == 6 and t < parse_hhmm("17:00"):     # Sunday before 17:00
                state = "sleep"
                weekend_reason = "sun_before_1700"

            # Daily time-of-day blackouts (if configured)
            if in_tod_blackout(now, tod_blackouts):
                state = "sleep"

            # Heartbeat / caps transitions
            if state == "caps" and not in_caps:
                in_caps = True
                log(
                    "caps_on",
                    reasons=caps_reasons,
                    day_realized=round(day_realized, 2),
                    day_peak=round(day_peak_realized, 2),
                    dayR=round(risk.day_R, 3),
                )
            if state != "caps" and in_caps:
                in_caps = False

            if state == "caps" and net_qty == 0:
                try:
                    c = 0
                    for t in ib.openTrades():
                        if not is_our_order_or_trade(t):
                            continue
                        st = (getattr(t.orderStatus, "status", "") or "").strip()
                        if st in ACTIVE_STATUSES:
                            safe_cancel(ib, t, note="[cap_sweep]")
                            c += 1
                    if c:
                        log("cap_sweep_all_orders", count=c)
                except Exception as e:
                    log("cap_sweep_err", err=str(e))

            # Weekend sweep: once we’re in weekend sleep, cancel all working orders
            if state == "sleep" and weekend_reason and not weekend_sweep_done:
                try:
                    c = 0
                    for t in ib.openTrades():
                        if not is_our_order_or_trade(t):
                            continue
                        st = (getattr(t.orderStatus, "status", "") or "").strip()
                        if st in ACTIVE_STATUSES:
                            safe_cancel(ib, t, note=f"[weekend_sweep:{weekend_reason}]")
                            c += 1
                    if c:
                        log("weekend_sweep_all_orders", count=c, reason=weekend_reason)

                    # NEW: auto-flat at Friday close so we never hold into the weekend
                    if weekend_reason == "fri_after_1600" and net_qty != 0 and args.place_orders:
                        flatten_market(net_qty)
                        log("weekend_auto_flat", reason=weekend_reason, qty=int(net_qty))
                except Exception as e:
                    log("weekend_sweep_err", err=str(e))
                weekend_sweep_done = True
            elif state == "active":
                # reset so next weekend we sweep again
                weekend_sweep_done = False

            # Idle reason for HB
            if state == "caps":
                idle_reason = "capped:" + ",".join(caps_reasons)
            elif state == "wait_rt":
                idle_reason = "waiting_for_rt_fresh"
            elif state == "sleep":
                idle_reason = f"sleep:{weekend_reason or 'outside_trade_window'}"
            else:
                # Scale min gap by cadence_scale so we can back off under stress
                eff_min_gap = int(max(1, args.min_seconds_between_entries * cadence_scale))
                if has_active_parent_entry(ib, con):
                    idle_reason = "parent_entry_working"
                elif not risk.can_trade(now, eff_min_gap):
                    gate_reason = risk.gate_reason(now, eff_min_gap)
                    if gate_reason == "cooldown":
                        idle_reason = "gated:cooldown"
                    elif gate_reason == "max_trades":
                        idle_reason = "gated:max_trades"
                    elif gate_reason == "dayR_cap":
                        idle_reason = "gated:dayR_cap"
                    elif gate_reason == "consec_losses":
                        idle_reason = "gated:consec_losses"
                    elif gate_reason == "post_flat_cooldown":
                        idle_reason = "gated:post_flat_cooldown"
                    elif gate_reason == "min_gap_between_entries":
                        idle_reason = "gated:min_gap_between_entries"
                    else:
                        idle_reason = f"gated:{gate_reason or 'unknown'}"
                elif args.require_new_bar_after_start and not startup_bar_seen:
                    idle_reason = "waiting_for_first_new_bar"
                elif len(C) < 60:
                    idle_reason = "waiting_for_bars"
                else:
                    idle_reason = "active_waiting"

            hb_update(
                state=state,
                idle_reason=idle_reason,
                in_session_window=within_session(now, args.trade_start_ct, args.trade_end_ct),
                caps=caps_reasons,
                dayR=round(risk.day_R, 3),
                trades_today=int(risk.trades),
                cool_until=(str(risk.cool_until) if risk.cool_until else None),
            )

            # ===== ENTRY LOGIC (simple example arms) =====
                        # --- SHADOW LEARNING WHILE CAPPED (no orders placed) ---
            if (
                state == "caps"
                and args.learn_while_capped
                and learner is not None
                and len(C) >= 60
                and net_qty == 0
                and last_bar_ts is not None
            ):
                # Only run once per new bar
                if shadow_last_bar_ts != last_bar_ts:
                    shadow_last_bar_ts = last_bar_ts

                    close = C[-1]
                    _atrv = atr(H, L, C, 14)
                    _atrp = (_atrv / close) if (not math.isnan(_atrv) and close > 0) else float("nan")
                    fast = ema(C[-20:], 20)
                    slow = ema(C[-50:], 50)

                    is_trend = (fast > slow) and (not math.isnan(_atrp)) and _atrp >= args.gate_atrp
                    is_breakout = (
                        len(C) >= 30
                        and (close >= max(C[-20:]) or close <= min(C[-20:]))
                    )

                    # Optional BBBW gate (same as live entry)
                    bbbw_ok = True
                    if args.gate_bbbw > 0:
                        win = C[-20:]
                        m = sum(win) / 20.0
                        var = sum((x - m) * (x - m) for x in win) / 20.0
                        sd = math.sqrt(max(0.0, var))
                        if m > 0:
                            bbbw = (2 * 2.0 * sd) / m
                            bbbw_ok = bbbw >= float(args.gate_bbbw)
                        else:
                            bbbw_ok = False

                    cand: List[str] = []
                    if "trend" in arms_enabled and is_trend and bbbw_ok:
                        cand.append("trend")
                    if "breakout" in arms_enabled and is_breakout and bbbw_ok:
                        cand.append("breakout")

                    if cand:
                        if len(cand) == 1:
                            chosen = cand[0]
                        else:
                            chosen, probs = learner.choose(cand, sample=True)
                            if args.learn_log:
                                log(
                                    "shadow_caps_decision",
                                    cand=cand,
                                    probs={k: round(v, 3) for k, v in probs.items()},
                                    chosen=chosen,
                                    reasons=caps_reasons,
                                )

                        # 0R reward for "missed" opportunity while capped
                        _shadow_learn_on_veto(
                            chosen_arm=str(chosen),
                            reason="state=caps:" + ",".join(caps_reasons),
                            reward=0.0,
                            learner=learner,
                            strat_path=strat_path,
                            args=args,
                        )

            if (
                state == "active"
                and len(C) >= 60
                and not has_active_parent_entry(ib, con)
                and net_qty == 0
            ):
                # Enforce cooldown / spacing here
                eff_min_gap = int(max(1, args.min_seconds_between_entries * cadence_scale))
                if not risk.can_trade(now, eff_min_gap):
                    # Hard gate: do NOT consider a new entry yet
                    gate_reason = risk.gate_reason(now, eff_min_gap)
                    post_flat_remaining = risk.post_flat_cooldown_remaining()
                    log(
                        "entry_blocked_cooldown",
                        eff_min_gap=eff_min_gap,
                        last_entry_time=risk.last_entry_time,
                        cool_until=str(risk.cool_until) if risk.cool_until else None,
                        reason=gate_reason,
                        post_flat_remaining=(
                            round(post_flat_remaining, 3)
                            if post_flat_remaining is not None
                            else None
                        ),
                    )
                    if gate_reason == "post_flat_cooldown":
                        log(
                            "gate_skip",
                            reason="post_flat_cooldown",
                            remaining=(
                                round(post_flat_remaining, 3)
                                if post_flat_remaining is not None
                                else None
                            ),
                        )
                        hb_update(idle_reason="gated:post_flat_cooldown")
                    else:
                        hb_update(
                            idle_reason=f"gated:{gate_reason or 'cooldown_entry_block'}"
                        )
                else:
                    close = C[-1]
                    _atrv = atr(H, L, C, 14)
                    _atrp = (_atrv / close) if (not math.isnan(_atrv) and close > 0) else float("nan")
                    fast = ema(C[-20:], 20)
                    slow = ema(C[-50:], 50)

                    is_trend = (fast > slow) and (not math.isnan(_atrp)) and _atrp >= args.gate_atrp
                    is_breakout = (len(C) >= 30) and (
                        close >= max(C[-20:]) or close <= min(C[-20:])
                    )

                    # Optional BBBW gate (disabled by default via --gate-bbbw 0)
                    bbbw_ok = True
                    if args.gate_bbbw > 0:
                        win = C[-20:]
                        m = sum(win) / 20.0
                        var = sum((x - m) * (x - m) for x in win) / 20.0
                        sd = math.sqrt(max(0.0, var))
                        if m > 0:
                            bbbw = (2 * 2.0 * sd) / m
                            bbbw_ok = bbbw >= float(args.gate_bbbw)
                        else:
                            bbbw_ok = False
                        if not bbbw_ok:
                            hb_update(idle_reason="gated:bbbw_low")

                    # Candidate strategy arms
                    cand: List[str] = []
                    if "trend" in arms_enabled and is_trend and bbbw_ok:
                        cand.append("trend")
                    if "breakout" in arms_enabled and is_breakout and bbbw_ok:
                        cand.append("breakout")

                    if cand:
                        # 1) Bandit choice as before
                        if len(cand) == 1:
                            chosen = cand[0]
                            probs = {chosen: 1.0}
                        else:
                            chosen, probs = learner.choose(cand, sample=(args.learn_mode != "shadow"))
                            if args.learn_mode in ("shadow", "advisory"):
                                log(
                                    "learn_decision",
                                    cand=cand,
                                    probs={k: round(v, 3) for k, v in probs.items()},
                                    chosen=chosen,
                                )

                        # 2) Build snapshot for AI advisory/guardrails
                        snapshot = {
                            "ts": utc_now_str(),
                            "price": float(close),
                            "atr": float(_atrv) if not math.isnan(_atrv) else None,
                            "atrp": float(_atrp) if not math.isnan(_atrp) else None,
                            "fast_ema": float(fast) if not math.isnan(fast) else None,
                            "slow_ema": float(slow) if not math.isnan(slow) else None,
                            "is_trend": bool(is_trend),
                            "is_breakout": bool(is_breakout),
                            "bbbw_ok": bool(bbbw_ok),
                            "arms_enabled": arms_enabled,
                            "bandit_probs": {k: float(v) for k, v in probs.items()},
                            "risk": {
                                "day_R": float(risk.day_R),
                                "trades_today": int(risk.trades),
                                "consec_losses": int(risk.consec_losses),
                            },
                            "state": state,
                            "session_key": k,
                        }

                        # 3) AI advisory (shadow only – no hard decisions yet)
                        advice = None
                        try:
                            advice = ai.advisory_decision(
                                snapshot=snapshot,
                                raw_candidate_arms=cand,
                                bandit_choice=chosen,
                            )
                        except Exception as e:
                            log("ai_advisory_err", err=str(e))

                        # 4) AI guardrails veto (optional)
                        allowed = True
                        veto_reason = ""
                        try:
                            allowed, veto_reason = ai.guardrails_check(snapshot, advice)
                        except Exception as e:
                            log("ai_guard_err", err=str(e))

                        if not allowed:
                            log("ai_entry_veto", reason=veto_reason, chosen=chosen, cand=cand)
                            try:
                                _shadow_learn_on_veto(
                                    chosen_arm=str(chosen),
                                    reason=f"ai_guard:{veto_reason}",
                                    reward=0.0,
                                    learner=learner,
                                    strat_path=strat_path,
                                    args=args,
                                )
                            except Exception:
                                pass
                        else:
                            # Simple mapping: trend → with trend, breakout → breakout direction
                            go_long = (
                                True
                                if (chosen == "trend" and fast >= slow)
                                else (close >= max(C[-20:]))
                            )
                            if args.learn_mode != "shadow":
                                place_bracket(go_long, close, last_bar_ts, net_qty, signal_name=chosen)
                                current_arm = chosen


            # Sweep orphans regularly (but only ours) - throttled
            now_ts = time.time()
            if now_ts - last_orphan_sweep_time >= 30.0:
                reconcile_orphans(ib, ib_acct or "", con)
                last_orphan_sweep_time = now_ts

            ib.sleep(1.0)


    except KeyboardInterrupt:
        print("INFO [CTRL-C] Shutting down...")
    finally:
        try:
            persist_day_state_snapshot()
        except Exception:
            pass
        # Final learner save
        try:
            save_thompson(strat_path, learner)
            if param_learner:
                save_thompson(param_path, param_learner)
        except Exception:
            pass
        try:
            sent = getattr(getattr(ib, "client", None), "bytesSent", 0) or 0
            recv = getattr(getattr(ib, "client", None), "bytesReceived", 0) or 0
            print(
                f"Disconnecting from {args.host}:{args.port}, "
                f"{sent/1024:.0f} kB sent, {recv/1024:.0f} kB received."
            )
        except Exception:
            pass
        try:
            ib.disconnect()
            print("Disconnected.")
        except Exception:
            pass


if __name__ == "__main__":
    main()






















































